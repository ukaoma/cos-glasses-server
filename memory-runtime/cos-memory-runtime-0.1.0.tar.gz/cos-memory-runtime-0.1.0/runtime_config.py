"""Per-installation paths. The package never includes instance data."""
import json
import os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CONFIG=ROOT/'instance.json'

def configure():
    data=json.loads(CONFIG.read_text())
    if data.get('schema')!=1 or not data.get('owner'):raise ValueError('instance_configuration_invalid')
    root=Path(data['data_root']).expanduser().resolve()
    os.environ['COS_MEMORY_JOURNAL_DIR']=str(root/'journal')
    os.environ['COS_MEMORY_STATE_DIR']=str(root/'state')
    os.environ['COS_MEMORY_SOURCE_REGISTRY']=str(root/'sources.json')
    os.environ['COS_STANDING_RULES_PATH']=str(root/'rules.md')
    os.environ['COS_MEMORY_EVAL_DIR']=str(root/'evaluations')
    os.environ['COS_GRAPH_INDEX_PATH']=str(root/'graph.sqlite')
    os.environ['COS_INSTANCE_OWNER']=data['owner']
    return data
