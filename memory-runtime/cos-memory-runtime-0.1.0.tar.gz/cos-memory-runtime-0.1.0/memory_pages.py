"""Private frozen pages. New inserts do not move a cursor; changed visibility invalidates it."""
import json
import re
import time
import uuid
from memory_journal import JournalError, now

TTL_SECONDS=300

def visibility(journal):
    from memory_source_policy import grant_fingerprint
    scope=grant_fingerprint()
    if not journal.governed:return {'policy':None,'epoch':None,'heads':{},'grants':scope}
    manifest=journal.manifest();checkpoint=journal.checkpoint(manifest)
    return {'grants':scope,'policy':manifest['policy']['revision'],'epoch':checkpoint['epoch'],
            'heads':{key:[head['revision'],head['state']] for key,head in manifest['heads'].items()
                     if key.startswith(('memory:','policy:','source:','rule:','identity:'))}}

def check_visibility(before,after):
    if before.get('grants')!=after.get('grants') or before['policy']!=after['policy'] or before['epoch']!=after['epoch']:
        raise JournalError('cursor_restart_required')
    if any(after['heads'].get(key)!=value for key,value in before['heads'].items()):
        raise JournalError('cursor_restart_required')

def page(request,journal,namespace,collect):
    # Governed writers share this fence. Freeze payloads and their visibility in one read generation.
    if journal.governed:
        with journal.locked():return _page_locked(request,journal,namespace,collect)
    return _page_locked(request,journal,namespace,collect)

def _page_locked(request,journal,namespace,collect):
    limit=max(1,min(int(request.get('limit',25)),50));root=journal.state_root/'pages'/namespace
    root.mkdir(parents=True,exist_ok=True,mode=0o700)
    query={k:request.get(k) for k in ('q','days','kinds','review') if k in request}
    before=visibility(journal)
    if request.get('cursor'):
        try:
            sid,offset=request['cursor'].split(':');offset=int(offset)
            if not re.fullmatch('[a-f0-9]{32}',sid) or offset<0:raise ValueError()
            snap=json.loads((root/(sid+'.json')).read_text())
        except (OSError,ValueError,TypeError):raise JournalError('invalid_cursor')
        if snap['query']!=query or time.time()-snap['epoch']>TTL_SECONDS:raise JournalError('cursor_restart_required')
        check_visibility(snap['visibility'],before)
    else:
        data=collect();after=visibility(journal);check_visibility(before,after);before=after
        snap={**data,'query':query,'visibility':before,'epoch':time.time(),'generated_at':now()}
        sid=uuid.uuid4().hex;offset=0
        journal._write(root/(sid+'.json'),snap)
        for old in root.glob('*.json'):
            if time.time()-old.stat().st_mtime>TTL_SECONDS:old.unlink(missing_ok=True)
    rows=snap['rows'];result={k:v for k,v in snap.items() if k not in {'rows','query','visibility','epoch'}}
    result.update(items=rows[offset:offset+limit],matched_total=len(rows),returned_count=len(rows[offset:offset+limit]),
                  snapshot_id=sid,next_cursor=f'{sid}:{offset+limit}' if offset+limit<len(rows) else None)
    check_visibility(before,visibility(journal))
    return result
