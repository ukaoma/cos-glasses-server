"""Public journal event adapter; no private correction or meeting stores are imported."""
from datetime import datetime,timezone
from types import SimpleNamespace
from memory_journal import MemoryJournal,digest
EPOCH_TS='1970-01-01T00:00:00+00:00'

def _to_utc(value):return value or EPOCH_TS

def _make_event(store,key,event_type,ts,**kwargs):
    return {'event_id':'evt_'+digest([store,key])[:16],'store':store,'event_type':event_type,'ts':ts,**kwargs}

def _public(value):return value

def _collect(days,include_memory=True):
    journal=MemoryJournal();events=[]
    for row in journal.list('memory',review=True):
        events.append(_make_event('bot_memory',row['id']+':'+str(row['revision']),'captured',row['updated_at'],lesson_id=row['id'],title=str(row['payload'].get('content') or '')[:180],source_refs=[]))
    from memory_trace import learning_rows
    events.extend(learning_rows(journal))
    return SimpleNamespace(events=events,coverage={'journal':{'state':'ok','count':len(events)}})

def list_to_review(limit=100000):
    return {'events':[],'coverage':{'journal':{'state':'ok'}}}
