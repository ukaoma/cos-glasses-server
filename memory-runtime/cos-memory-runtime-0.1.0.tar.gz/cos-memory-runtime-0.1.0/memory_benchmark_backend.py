"""Opt-in owner command evaluator. No implicit provider, fallback, or model call."""
from dataclasses import dataclass
import json,os,shutil,time,uuid,tempfile
from memory_journal import JournalError
from process_supervisor import run_supervised
from runtime_config import configure

@dataclass(frozen=True)
class Profile:
    operation_id:str
    deadline:float
    reasoning_effort:str|None=None
    prompt_version:str='memory-replay-1'

def resolve_profile(provider,model,timeout,purpose):
    if provider!='external_command':raise JournalError('public_evaluator_requires_external_command')
    if not 0<timeout<=600:raise JournalError('invalid_evaluation_timeout')
    return Profile(str(uuid.uuid4()),time.monotonic()+timeout)

def call_llm(prompt,*,model,timeout,_audit_caller,profile):
    try:command=json.loads(os.environ['COS_MEMORY_EVAL_COMMAND'])
    except (KeyError,ValueError):raise JournalError('set_explicit_evaluator_command_json')
    if not isinstance(command,list) or not command or any(not isinstance(v,str) for v in command) or not shutil.which(command[0]):raise JournalError('invalid_evaluator_command')
    command[0]=os.path.abspath(shutil.which(command[0]))
    with tempfile.TemporaryDirectory(prefix='cos-evaluation-') as isolated_cwd:
        process=run_supervised(command,input=prompt,timeout=min(timeout,max(.01,profile.deadline-time.monotonic())),cwd=isolated_cwd,env={**os.environ,'COS_MODEL_EVALUATION':'1','CLAUDE_CODE_SAFE_MODE':'1'})
    if process.returncode:raise JournalError('evaluator_command_failed')
    return process.stdout

def _extract_json(response):return json.loads(response)
