"""Owner review operations exposed by the versioned workspace protocol."""
from memory_journal import JournalError
from memory_pages import page


def dispatch(request,journal):
    import memory_curation as curation
    action=request['action']
    if action=='rule_page':
        def collect():
            rows=journal.list('rule',review=True) if journal.available else []
            rows.sort(key=lambda row:(row['updated_at'],row['id']),reverse=True)
            return {'rows':rows,'complete':True}
        return page(request,journal,'rules',collect)
    if action=='propose_rule':
        payload=request.get('payload',{})
        if not isinstance(payload,dict) or set(payload)-{'lesson_id','text','evidence_refs','trigger','exclusions'}:
            raise JournalError('invalid_rule_proposal')
        if not isinstance(payload.get('lesson_id'),str) or not 1<=len(payload['lesson_id'])<=256:raise JournalError('invalid_lesson_id')
        if not isinstance(payload.get('evidence_refs'),list) or not all(isinstance(x,str) and len(x)<=300 for x in payload['evidence_refs']):
            raise JournalError('invalid_rule_evidence')
        if not isinstance(payload.get('trigger',''),str) or len(payload.get('trigger',''))>2000 or not isinstance(payload.get('exclusions',[]),list) or not all(isinstance(x,str) and len(x)<=2000 for x in payload.get('exclusions',[])):
            raise JournalError('invalid_rule_applicability')
        return curation.propose(payload.get('lesson_id'),payload.get('text'),evidence_refs=payload['evidence_refs'],trigger=payload.get('trigger',''),exclusions=payload.get('exclusions',[]),journal=journal)
    rule_id=request.get('id')
    if not isinstance(rule_id,str) or not rule_id.startswith('rule_'):raise JournalError('invalid_rule_id')
    if action=='rule_evaluation':return curation.evaluation(rule_id,request.get('evaluation_id'),journal,inspect=True)
    kwargs={'expected_revision':request.get('expected_revision'),'idempotency_key':request.get('idempotency_key'),'journal':journal}
    if action=='review_rule':return curation.review(rule_id,**kwargs)
    if action=='activate_rule':return curation.activate(rule_id,evaluation_id=request.get('evaluation_id'),**kwargs)
    if action=='rollback_rule':return curation.rollback(rule_id,**kwargs)
    raise JournalError('unsupported_stewardship_action')
