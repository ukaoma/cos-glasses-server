"""Correlated evidence, without inferring use from retrieval or self-report from success."""
import json
from memory_journal import MemoryJournal,JournalError,digest,now

STAGES={'retrieved','included','opportunity','applied','checked'}
EVIDENCE={'retrieval_log','context_emitted','model_report','human_review','deterministic_check'}

def record(stage,run_id,memories,*,evidence_type,source_ref='',outcome=None,opportunity=None,session_id=None,journal=None):
    journal=journal or MemoryJournal()
    from memory_contract import automatic_memory_opted_out
    if automatic_memory_opted_out():return {'status':'suppressed','reason':'global_no_store'}
    if not journal.governed:return {'status':'not_instrumented','reason':'journal_adoption_required'}
    if stage not in STAGES or evidence_type not in EVIDENCE:raise JournalError('invalid_trace')
    if not isinstance(run_id,str) or not 1<=len(run_id)<=200:raise JournalError('invalid_run_id')
    if stage=='included' and evidence_type!='context_emitted':raise JournalError('invalid_inclusion_evidence')
    if stage=='checked' and (outcome not in {'passed','failed','inconclusive','unknown'} or evidence_type not in {'model_report','human_review','deterministic_check'}):raise JournalError('invalid_outcome')
    if stage in {'applied','checked','opportunity'} and not source_ref:raise JournalError('trace_evidence_required')
    refs=[]
    for item in memories:
        memory_id=item.get('id');value=journal.get('memory',memory_id)
        if not value:continue
        revision=item.get('journal_revision',item.get('revision',value['revision']))
        if revision!=value['revision']:raise JournalError('trace_revision_changed')
        refs.append({'id':memory_id,'revision':revision})
    if not refs:return {'status':'no_eligible_memories'}
    refs.sort(key=lambda r:(r['id'],r['revision']))
    payload={'stage':stage,'run_id':run_id,'memories':refs,'evidence_type':evidence_type,'source_ref':str(source_ref)[:500],
             'outcome':outcome,'opportunity':opportunity}
    identifier='trace_'+digest(payload)
    return journal.mutate('trace',identifier,payload,expected_revision=0,idempotency_key=identifier,automatic=True,session_id=session_id)

def summary(journal=None):
    journal=journal or MemoryJournal()
    if not journal.governed:return {'state':'uninstrumented','unique_runs':0,'eligible_opportunities':0,'repeat_error_rate':None}
    manifest=journal.manifest();rows=journal.list('trace');runs=set();opportunities={};checks={};counts={}
    for row in rows:
        p=row['payload'];runs.add(p['run_id']);counts[p['stage']]=counts.get(p['stage'],0)+1
        sequence=manifest.get('committed_operations',{}).get(row['operation_id'],{}).get('generation',0)
        for ref in p['memories']:
            key=(p['run_id'],ref['id'],ref['revision'])
            if p['stage']=='opportunity' and p.get('opportunity') is True:
                opportunities.setdefault(key,(sequence,row['updated_at']))
            if p['stage']=='checked' and p['evidence_type'] in {'deterministic_check','human_review'}:
                checks.setdefault(key,[]).append((sequence,p['outcome'],row['updated_at']))
    by_run={};checked_dates={}
    for key,(opportunity_sequence,opportunity_time) in opportunities.items():
        valid=[item for item in checks.get(key,[]) if item[0]>opportunity_sequence]
        outcomes={item[1] for item in valid}
        result=next(iter(outcomes)) if len(outcomes)==1 else 'inconclusive'
        if result not in {'passed','failed'}:result='inconclusive'
        by_run.setdefault(key[0],[]).append(result)
        if valid:checked_dates.setdefault(key[0],[]).extend(item[2] for item in valid)
    # One task may touch several lessons. A failure cannot disappear behind another pass.
    results={run:'failed' if 'failed' in values else 'passed' if all(v=='passed' for v in values) else 'inconclusive' for run,values in by_run.items()}
    eligible={run:result for run,result in results.items() if result in {'passed','failed'}}
    from datetime import datetime
    dates=[datetime.fromisoformat(max(checked_dates[run])) for run in eligible]
    days=(max(dates)-min(dates)).total_seconds()/86400 if dates else 0
    ready=len(eligible)>=30 and days>=14
    return {'state':'ok','unique_runs':len(runs),'stage_event_counts':counts,'eligible_opportunities':len(by_run),
            'memory_revision_opportunities':len(opportunities),'checked_eligible_runs':len(eligible),
            'inconclusive_runs':sum(result=='inconclusive' for result in results.values()),
            'observation_days':round(days,2),'evidence_gate_met':ready,
            'repeat_error_rate':sum(result=='failed' for result in eligible.values())/len(eligible) if ready else None,
            'rate_limit_reason':None if ready else 'Requires 30 checked eligible runs over at least 14 days'}

def learning_rows(journal=None):
    from learning_events import _make_event,_to_utc
    journal=journal or MemoryJournal()
    if not journal.governed:return []
    rows=[]
    for row in journal.list('trace'):
        p=row['payload']
        for ref in p['memories']:
            if not journal.get('memory',ref['id']):continue
            rows.append(_make_event('memory_trace',row['id']+':'+ref['id'],p['stage'],_to_utc(row['updated_at']),
                lesson_id=ref['id'],title=p['stage'].capitalize()+' · '+p['evidence_type'],
                target={'kind':'memory','id':ref['id'],'version':ref['revision']},
                source_refs=[{'kind':p['evidence_type'],'id':p['source_ref'] or p['run_id']}],
                outcome={'name':p['run_id'],'result':p['outcome'],'evaluator':p['evidence_type'],'ts':row['updated_at']} if p['outcome'] else None,
                detail={'run_id':p['run_id'],'evidence_type':p['evidence_type'],'opportunity':p['opportunity']}))
    return rows

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['summary','record']);args=parser.parse_args()
    try:
        if args.action=='summary':result=summary()
        else:
            import sys
            body=json.loads(sys.stdin.read(65537))
            result=record(**body)
        print(json.dumps(result))
    except (JournalError,ValueError,TypeError) as exc:
        print(json.dumps({'error':str(exc)}));raise SystemExit(1)
