"""The portable file runtime does not configure or recover Qdrant collections."""
from memory_journal import JournalError

def build(*args,**kwargs):raise JournalError('vector_recovery_not_available_in_file_runtime')
def verify(*args,**kwargs):raise JournalError('vector_recovery_not_available_in_file_runtime')
