"""Validate owner-set admission thresholds without importing private cleanup jobs."""
def validate_patch(changes):
    if not isinstance(changes,dict) or set(changes)-{'min_words','min_distinct_chars','max_repeat_ratio','banned_patterns'}:raise ValueError('invalid_admission_policy')
    for key in ('min_words','min_distinct_chars'):
        if key in changes and (type(changes[key]) is not int or not 0<=changes[key]<=1000):raise ValueError('invalid_admission_threshold')
    if 'max_repeat_ratio' in changes and (type(changes['max_repeat_ratio']) not in {int,float} or not 0<=changes['max_repeat_ratio']<=1):raise ValueError('invalid_admission_ratio')
    if 'banned_patterns' in changes:
        import re
        if not isinstance(changes['banned_patterns'],list) or len(changes['banned_patterns'])>30:raise ValueError('invalid_banned_patterns')
        for pattern in changes['banned_patterns']:
            if not isinstance(pattern,str) or len(pattern)>500:raise ValueError('invalid_banned_pattern')
            re.compile(pattern)
    return changes

def read_guardrails():
    from memory_journal import MemoryJournal
    rules={'min_words':6,'min_distinct_chars':5,'max_repeat_ratio':0.8,'banned_patterns':[]}
    rules.update(MemoryJournal().policy().get('admission',{}))
    return {**rules,'llm_review':{'enabled':False,'supported':False,'max_per_run':0}}

def write_guardrails(changes):
    from memory_journal import MemoryJournal,digest
    clean=validate_patch(changes);journal=MemoryJournal();policy=journal.policy()
    journal.update_policy({'admission':{**policy.get('admission',{}),**clean}},expected_revision=policy['revision'],idempotency_key='guardrails_'+digest([policy['revision'],clean]))
    return read_guardrails()

def run(days=30,apply=False,llm=False):
    if llm:raise ValueError('model_review_not_configured_in_file_runtime')
    from datetime import datetime,timedelta,timezone
    from memory_journal import MemoryJournal,digest,now
    from memory_contract import validate_capture
    journal=MemoryJournal();rules=read_guardrails();cutoff=(datetime.now(timezone.utc)-timedelta(days=days)).isoformat()
    rows=sorted((r for r in journal.list('memory',review=True) if r['created_at']>=cutoff and r['state'] in {'active','candidate'}),key=lambda r:(r['created_at'],r['id']),reverse=True)
    # Separate review/apply passes so a preview never advances the applying pass.
    cursor=journal.state_root/'guardrail-cursors'/('public-'+digest([days,rules,bool(apply)])+'.json')
    with journal.locked():
        import json
        previous=json.loads(cursor.read_text()).get('after') if cursor.is_file() else None
        eligible=[r for r in rows if not previous or (r['created_at'],r['id'])<tuple(previous)]
        if not eligible:eligible=rows
        batch=eligible[:100];verdicts=[]
        for row in batch:
            reasons=[]
            if row['state']!='active':
                try:validate_capture(row['payload'].get('content',''),rules)
                except ValueError as exc:reasons=[str(exc)]
            verdicts.append({'id':row['id'],'revision':row['revision'],'verdict':'prune' if reasons else 'keep','reasons':reasons,'by':'rules','excerpt':row['payload'].get('content','')[:180],'applied':False})
    # Mutation methods take and recheck the same authority lock themselves.
    for verdict in verdicts:
        if apply and verdict['verdict']=='prune':
            row=journal.get('memory',verdict['id'],review=True)
            if row and row['revision']==verdict['revision']:
                journal.mutate('memory',row['id'],row['payload'],state='quarantined',expected_revision=row['revision'],idempotency_key='guardrail_'+digest([row['id'],row['revision'],rules]))
                verdict['applied']=True
    if batch:
        with journal.locked():journal._write(cursor,{'after':[batch[-1]['created_at'],batch[-1]['id']]})
    return {'run':{'days':days,'scanned':len(batch),'flagged':sum(v['verdict']=='prune' for v in verdicts),'kept':sum(v['verdict']=='keep' for v in verdicts),'review':0,'llm_reviewed':0,'llm_enabled':False,'applied':apply,'pruned':sum(v['applied'] for v in verdicts),'coverage':{'remaining_after_page':len(eligible)-len(batch),'complete_pass':len(eligible)==len(batch)},'at':now()},'verdicts':verdicts}
