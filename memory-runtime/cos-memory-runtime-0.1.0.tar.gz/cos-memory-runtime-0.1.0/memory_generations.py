"""Validated memory generation activation under the stable per-instance fence.

A pointer selects journal, graph and (when present) an isolated vector collection
in one durable write. It never changes the lock or independent deletion frontier.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import uuid
from memory_journal import MemoryJournal, JournalError, digest, now, sync_directory


def file_hash(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda:stream.read(1024*1024),b''):h.update(part)
    return h.hexdigest()


def tree_hash(root):
    root=Path(root)
    if root.is_symlink() or not root.is_dir():raise JournalError('unsafe_sdk_generation')
    files={}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():raise JournalError('unsafe_sdk_generation')
        if path.is_file():files[str(path.relative_to(root))]=file_hash(path)
        elif not path.is_dir():raise JournalError('unsafe_sdk_generation')
    if not files:raise JournalError('empty_sdk_generation')
    return digest(files)


def active_sdk(default,*,required=True):
    """Resolve the SDK store paired with the selected journal/graph generation.

    A replica deliberately receives no raw SDK files. Its SQLite/source graph
    remains readable, but SDK queries must not consult an unrelated old store.
    """
    journal=MemoryJournal();value=binding(journal.state_root)
    if value and value.get('sdk'):
        path=Path(value['sdk'])
        if not path.is_absolute() or path.is_symlink() or not path.is_dir():raise JournalError('sdk_generation_unavailable')
        return path
    if value and required:raise JournalError('sdk_generation_not_available')
    return Path(default)


def binding(state_root):
    path=Path(state_root)/'serving.json'
    if not path.exists():
        floor=Path(state_root)/'reader-floor.json'
        if floor.exists():
            try:required=json.loads(floor.read_text()).get('serving_pointer_required')
            except (OSError,ValueError) as exc:raise JournalError('reader_floor_corrupt') from exc
            if required:raise JournalError('serving_generation_unavailable')
        return None
    try:
        data=json.loads(path.read_text());raw={k:v for k,v in data.items() if k!='checksum'}
        if data.get('schema')!=1 or data.get('checksum')!=digest(raw):raise ValueError()
        target=Path(data['journal'])
        if not target.is_absolute() or target.is_symlink() or not target.is_dir():raise ValueError()
        return data
    except (OSError,ValueError,KeyError,TypeError) as exc:raise JournalError('serving_generation_invalid') from exc


def recovery_binding(state_root,logical_root):
    """Explicit recovery handle; ordinary readers never fall back to old data."""
    path=Path(state_root)/'activation-intent.json'
    try:
        intent=json.loads(path.read_text())
        if intent.get('checksum')!=digest({k:v for k,v in intent.items() if k!='checksum'}) or intent.get('logical_root')!=str(logical_root):raise ValueError()
        receipt=Path(state_root)/'activation-receipts'/(intent['activation_id']+'.json')
        previous=Path(intent['pointer']['journal'] if receipt.is_file() else intent['previous_journal'])
        if not previous.is_absolute() or previous.is_symlink():raise ValueError()
        result={'journal':str(previous)}
        generation=previous.parent/'generation.json'
        if generation.is_file():
            spec=json.loads(generation.read_text())
            if spec.get('checksum')!=digest({k:v for k,v in spec.items() if k!='checksum'}) or spec.get('journal')!=str(previous):raise ValueError()
            for key in ('sdk','graph','logical_collection','vector_collection'):
                if spec.get(key):result[key]=spec[key]
        return result
    except (OSError,ValueError,KeyError,TypeError) as exc:raise JournalError('activation_recovery_intent_invalid') from exc


def _apply_checkpoint(root,checkpoint,journal):
    manifest=json.loads((root/'manifest.json').read_text())
    for key,revision in checkpoint['tombstones'].items():
        old=manifest['heads'].get(key,{})
        manifest['heads'][key]={**old,'state':'deleted','blob':None,'revision':max(revision,old.get('revision',0))}
    for path in (root/'blobs').glob('*.json'):
        value=json.loads(path.read_text())
        if value['kind']+':'+value['id'] in checkpoint['tombstones']:path.unlink()
    for path in (root/'projections').glob('*.json'):
        if 'memory:'+str(json.loads(path.read_text()).get('id')) in checkpoint['tombstones']:path.unlink()
    manifest['deletion_epoch']=checkpoint['epoch'];journal._write(root/'manifest.json',manifest)


def active_graph(default):
    journal=MemoryJournal();value=binding(journal.state_root)
    return Path(value['graph']) if value and value.get('graph') else Path(default)


def active_collection(collection):
    journal=MemoryJournal();value=binding(journal.state_root)
    if value and collection==value.get('logical_collection'):
        return value['vector_collection']
    return collection


def _validate_journal(root,checkpoint):
    manifest=json.loads((root/'manifest.json').read_text())
    from memory_journal import SCHEMA,READER
    if manifest.get('schema')!=SCHEMA or manifest.get('min_reader',999)>READER or manifest['corpus_id']!=checkpoint['corpus_id']:raise JournalError('generation_identity_mismatch')
    if manifest.get('deletion_epoch')!=checkpoint['epoch']:raise JournalError('deletion_frontier_mismatch')
    if any(p.is_symlink() for p in root.rglob('*')):raise JournalError('unsafe_generation_member')
    for key,head in manifest['heads'].items():
        if key in checkpoint['tombstones']:
            if head['state']!='deleted' or head.get('blob'):raise JournalError('deleted_record_in_generation')
            continue
        if head['state']=='deleted':raise JournalError('incomplete_deletion_frontier')
        path=root/'blobs'/(head['blob']+'.json')
        value=json.loads(path.read_text())
        if digest(value)!=head['blob'] or value['kind']+':'+value['id']!=key or value['revision']!=head['revision'] or value['state']!=head['state'] or value['owner']!=manifest['owner'] or value['audience']!=[manifest['owner']]:raise JournalError('generation_blob_mismatch')
    return manifest


def prepare(snapshot,destination,*,journal=None,graph_index=None,client=None,logical_collection=None,replica=None,sdk_root=None,journal_update=None):
    """Reconcile a snapshot with surviving current records. Never roll back new captures.

    Vector tasks retain their original embeddings/physical IDs. A graph is copied
    from an explicit already validated read model. Activation refuses intervening
    writes; preparation can be repeated into a new destination.
    """
    if journal is None:
        try:journal=MemoryJournal()
        except JournalError as exc:
            if exc.code not in {'serving_generation_unavailable','serving_generation_invalid'}:raise
            journal=MemoryJournal(_recovery=True)
    selected = recovery_binding(journal.state_root,journal.logical_root) if getattr(journal, '_recovery', False) else binding(journal.state_root)
    if selected and selected.get('sdk') and not replica and sdk_root is None:
        raise JournalError('sdk_recovery_requires_complete_generation')
    if selected and selected.get('graph') and not replica and graph_index is None:
        raise JournalError('graph_recovery_requires_complete_generation')
    if selected and selected.get('vector_collection') and not replica and (client is None or logical_collection!=selected.get('logical_collection')):
        raise JournalError('vector_recovery_requires_complete_generation')
    dest=Path(destination).resolve()
    if dest.exists():raise JournalError('generation_destination_exists')
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.mkdir(mode=0o700)
    try:
        sdk=None
        if sdk_root:
            source=Path(sdk_root).resolve(strict=True)
            tree_hash(source)
            shutil.copytree(source,dest/'sdk');sdk=str(dest/'sdk')
        journal.restore(snapshot,dest/'journal')
        with journal.locked():
            checkpoint=journal.checkpoint();live=journal.manifest() if journal.available else None
            expected=digest(live) if live else None
            # The surviving current generation wins every revision conflict.
            if replica:
                import socket
                if manifest_identity := replica.get("authority_host"):
                    if manifest_identity == socket.gethostname():raise JournalError("replica_authority_is_local")
                else:raise JournalError("replica_authority_required")
            if live and not replica:
                if live['corpus_id']!=checkpoint['corpus_id']:raise JournalError('generation_identity_mismatch')
                if any(p.is_symlink() for p in journal.root.rglob('*')):raise JournalError('unsafe_generation_member')
                shutil.rmtree(dest/'journal');shutil.copytree(journal.root,dest/'journal')
                _apply_checkpoint(dest/'journal',checkpoint,journal)
            manifest=_validate_journal(dest/'journal',checkpoint)
            if journal_update:
                if replica or not live:raise JournalError('local_mutation_candidate_required')
                journal._authority(live)
                staged=MemoryJournal(dest/'journal',dest/'mutation-state')
                staged._write_checkpoint(checkpoint)
                from memory_journal import SCHEMA,READER
                staged._write(staged.reader_floor_path,{'schema':SCHEMA,'min_reader':READER,'corpus_id':manifest['corpus_id'],'root':str(staged.root)})
                journal_update(staged)
                manifest=_validate_journal(dest/'journal',checkpoint)
            graph=None
            if graph_index:
                source=Path(graph_index).resolve(strict=True)
                with sqlite3.connect(f'file:{source}?mode=ro',uri=True) as db:
                    with sqlite3.connect(dest/'graph.sqlite') as target:db.backup(target)
                with sqlite3.connect(dest/'graph.sqlite') as db:
                    if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise JournalError('graph_integrity_failed')
                    tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                    if not {'entities','edges','chunks','docs','meta'}<=tables:raise JournalError('graph_schema_invalid')
                graph=str(dest/'graph.sqlite')
            vector=None;vector_hash=None;count=0
            if client is not None:
                from memory_generation_vectors import build
                vector,vector_hash,count=build(dest/'journal',manifest,client,logical_collection)
            elif logical_collection:raise JournalError('vector_client_required')
            spec={'schema':1,'created_at':now(),'corpus_id':manifest['corpus_id'],'journal':str(dest/'journal'),
                  'journal_hash':digest(manifest),'expected_live_hash':expected,'deletion_checkpoint':digest(checkpoint),
                  'graph':graph,'graph_hash':file_hash(graph) if graph else None,'logical_collection':logical_collection,
                  'vector_collection':vector,'vector_hash':vector_hash,'vector_count':count,'state':'validated_not_serving'}
            if replica:spec['replica']=replica
            if sdk:spec.update(sdk=sdk,sdk_hash=tree_hash(sdk))
            journal._write(dest/'generation.json',{**spec,'checksum':digest(spec)})
            for file in dest.rglob('*'):
                if file.is_file():
                    with file.open('rb') as stream:os.fsync(stream.fileno())
            for directory in sorted((p for p in dest.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):sync_directory(directory)
            sync_directory(dest);sync_directory(dest.parent)
            return spec
    except Exception:
        # Failed staged data is retained for inspection; no pointer has changed.
        raise



def activate(destination,*,journal=None,client=None):
    if journal is None:
        try:journal=MemoryJournal()
        except JournalError as exc:
            if exc.code not in {'serving_generation_unavailable','serving_generation_invalid'}:raise
            journal=MemoryJournal(_recovery=True)
    dest=Path(destination).resolve(strict=True)
    with journal.locked():
        spec=json.loads((dest/'generation.json').read_text());raw={k:v for k,v in spec.items() if k!='checksum'}
        if spec.get('schema')!=1 or spec.get('checksum')!=digest(raw):raise JournalError('generation_checksum_mismatch')
        if spec.get('journal')!=str(dest/'journal') or (spec.get('graph') and spec['graph']!=str(dest/'graph.sqlite')):raise JournalError('unsafe_generation_path')
        if spec.get('sdk') and spec['sdk']!=str(dest/'sdk'):raise JournalError('unsafe_generation_path')
        operation_id=digest({'destination':str(dest),'checksum':spec['checksum']})
        receipt_path=journal.state_root/'activation-receipts'/(operation_id+'.json')
        recovered_pointer=None
        try:current_pointer=binding(journal.state_root)
        except JournalError:
            current_pointer=None
            # An object created before the interrupted activation may retry.
            recovered_pointer=recovery_binding(journal.state_root,journal.logical_root)
        if current_pointer and current_pointer.get('activation_id')==operation_id:
            receipt={'status':'serving','activation_id':operation_id,'generation':current_pointer['generation'],'deletion_epoch':current_pointer['deletion_epoch'],'journal':current_pointer['journal']}
            journal._write(receipt_path,receipt);return receipt
        if receipt_path.exists():
            if current_pointer:return {**json.loads(receipt_path.read_text()),'status':'superseded_activation_receipt'}
            raise JournalError('serving_pointer_recovery_required')
        if spec.get('sdk') or ((current_pointer or recovered_pointer or {}).get('sdk')):
            from memory_ingest_fence import local_ingest_mode
            if local_ingest_mode() != 'exclusive':raise JournalError('sdk_activation_requires_ingest_fence')
        checkpoint=journal.checkpoint()
        floor=json.loads(journal.reader_floor_path.read_text())
        from memory_journal import READER,SCHEMA
        if floor.get('corpus_id')!=checkpoint['corpus_id'] or floor.get('schema')!=SCHEMA or floor.get('min_reader',999)>READER:raise JournalError('reader_floor_mismatch')
        if digest(checkpoint)!=spec['deletion_checkpoint']:raise JournalError('deletion_frontier_changed')
        if current_pointer is None and floor.get('serving_pointer_required'):
            prior=recovery_binding(journal.state_root,journal.logical_root)
            prior_path=Path(prior['journal'])/'manifest.json'
            live=json.loads(prior_path.read_text()) if prior_path.is_file() else None
        else:live=journal.manifest() if journal.available else None
        if (digest(live) if live else None)!=spec['expected_live_hash']:raise JournalError('generation_changed_reprepare')
        manifest=_validate_journal(dest/'journal',checkpoint)
        if not spec.get('replica'):
            import socket
            if manifest.get('authority_host') != socket.gethostname() or not manifest.get('authority_epoch'):
                raise JournalError('not_memory_authority')
            # Explicit recovery handles remain read-only to ordinary mutation;
            # this validated CAS is the only route allowed to restore serving.
            journal.checkpoint(manifest)
        if digest(manifest)!=spec['journal_hash']:raise JournalError('generation_changed_after_validation')
        if live and (live['owner']!=manifest['owner'] or live['authority_host']!=manifest['authority_host'] or live['authority_epoch']!=manifest['authority_epoch']):raise JournalError('authority_handoff_required')
        if spec['graph'] and file_hash(spec['graph'])!=spec['graph_hash']:raise JournalError('graph_changed_after_validation')
        if spec.get('sdk') and tree_hash(spec['sdk'])!=spec.get('sdk_hash'):raise JournalError('sdk_changed_after_validation')
        if spec['vector_collection']:
            if client is None:raise JournalError('vector_client_required')
            from memory_generation_vectors import verify
            if verify(getattr(client,'raw',client),spec['vector_collection'],spec['vector_count'])!=spec['vector_hash']:raise JournalError('vector_changed_after_validation')
        previous=current_pointer
        if previous:journal._write(journal.state_root/'previous-serving.json',previous)
        pointer={k:spec[k] for k in ('schema','corpus_id','journal','graph','logical_collection','vector_collection')}
        if spec.get('replica'):pointer['replica']=spec['replica']
        if spec.get('sdk'):pointer['sdk']=spec['sdk']
        pointer.update(activated_at=now(),generation=manifest['generation'],deletion_epoch=checkpoint['epoch'],activation_id=operation_id)
        intent={'schema':1,'activation_id':operation_id,'logical_root':str(journal.logical_root),'previous_journal':str(journal.root),'destination':str(dest),'pointer':{**pointer,'checksum':digest(pointer)}}
        journal._write(journal.state_root/'activation-intent.json',{**intent,'checksum':digest(intent)})
        journal._write(journal.reader_floor_path,{**floor,'serving_pointer_required':True})
        journal._write(journal.state_root/'serving.json',{**pointer,'checksum':digest(pointer)})
        receipt={'status':'serving','activation_id':operation_id,'generation':manifest['generation'],'deletion_epoch':checkpoint['epoch'],'preserved_latest_records':bool(live),'journal':spec['journal']}
        journal._write(receipt_path,receipt);return receipt
