"""Public journal reads; keyword ranking is explicit and requires no vector service."""
import re
from memory_journal import MemoryJournal

def all_memory_records():
    return [{**r['payload'],'id':r['id'],'journal_revision':r['revision'],'created_at':r['created_at'],'updated_at':r['updated_at']} for r in MemoryJournal().list('memory')]

def search_memory(query,limit=10,**kwargs):
    words=set(re.findall(r'\w+',query.casefold()))
    rows=[]
    for row in all_memory_records():
        terms=set(re.findall(r'\w+',str(row.get('content','')).casefold()))
        score=len(words&terms)/max(1,len(words))
        if score:rows.append({**row,'score':score,'search_method':'keyword'})
    return sorted(rows,key=lambda r:(r['score'],r['id']),reverse=True)[:limit]

def _salience_multiplier(row):return 1
