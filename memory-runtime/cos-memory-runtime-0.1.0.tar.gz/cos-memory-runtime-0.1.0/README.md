# COS public memory runtime 0.1.0

Requires Python 3.11+ on macOS or Linux. No third-party Python package is required.

1. Extract into a permanent installation directory.
2. Run `python3 install.py --data-root /absolute/path/to/your/private-data`.
3. Set COS_SCRIPTS_DIR to that installation directory in the COS server configuration and restart the server.
4. Add an explicitly granted document with `venv/bin/python3 manage.py grant /path/to/notes.md --title "Project"`.

The instance has a unique owner and an independent data directory. Captures begin as review candidates. Review controls, versioned rules, source snapshots, explicit document links, graph paths, user assertions and saved explorations use protocol 1. `[[Idea]]` links form the initial document graph. Memory search is keyword based in this bundle. Optional semantic embeddings and inferred extraction are not included; no model is invoked implicitly.

A source can be refreshed from the GUI; run `manage.py index` after changing document links. A backup is created with `manage.py backup /path/to/new-snapshot`. Restore stages into a new directory with `manage.py restore /path/to/snapshot --destination /path/to/new-restore`; it requires the independently preserved latest deletion checkpoint and does not overwrite the active corpus. After inspecting the prepared generation, run `manage.py activate /path/to/new-restore` to select it atomically. Keep checkpoint recovery copies separately. Protected backups and original documents retain content until separately purged.

Rule evaluation is explicit. Author a JSON suite with trigger, counterexample, exclusion and regression cases, evidence for current/proposed conditions, and deterministic expected answers/citations. Set `COS_MEMORY_EVAL_COMMAND` to a JSON argument array for an owner-selected evaluator that reads the test prompt from stdin and returns the requested JSON to stdout. Run `venv/bin/python3 memory_benchmark.py suite.json --output run.json --provider external_command --model your-requested-model --memory proposed --rule-id RULE_ID --evaluation-id EVAL_ID`. The runner injects the exact owner-reviewed rule, bounds the subprocess, scores its actual output and writes a locally attested evaluation. Enter EVAL_ID in the GUI to review evidence before activation. A requested model label is not proof of the model that actually executed. Do not use self-reported success or imported unsigned JSON as activation evidence.

Upgrade by verifying the new bundle, replacing code files only, and running the installer with the same data root. Preserve instance.json, the venv, and the private data root. Do not copy private notes or instance data into a distributable package. This release is owner-local; it does not add household sharing or SaaS tenant authentication.
