"""Learning list and status share one explicit reporting snapshot."""
from datetime import datetime,timedelta,timezone
from memory_pages import page

def learning_page(request,journal):
    import learning_events as le
    days=max(1,min(int(request.get('days',90)),3650))
    def collect():
        end=datetime.now(timezone.utc);start=end-timedelta(days=days)
        collector=le._collect(days,include_memory=True)
        events=[e for e in collector.events if e['ts']==le.EPOCH_TS or start.isoformat()<=e['ts']<=end.isoformat()]
        if journal.governed:
            heads=journal.manifest()['heads']
            for event in events:
                head=heads.get('memory:'+str(event.get('lesson_id','')))
                if head and head['state']!='deleted':event.update(governance=head['state'],journal_revision=head['revision'])
        events.sort(key=lambda e:e['event_id']);events.sort(key=lambda e:e['ts'],reverse=True)
        counts={}
        for event in events:counts[event['event_type']]=counts.get(event['event_type'],0)+1
        coverage=collector.coverage
        complete=all(c['state'] in {'ok','no_store','uninstrumented'} for c in coverage.values())
        return {'rows':[le._public(e) for e in events],'counts_by_type':counts,'coverage':coverage,
                'stores':{key:{**value,'readable':value['state']=='ok'} for key,value in coverage.items()},
                'complete':complete,'window_start':start.isoformat(),'window_end':end.isoformat(),'days':days,
                'excluded_types':[],'source_as_of':end.isoformat(),
                'unknown_time_count':sum(e['ts']==le.EPOCH_TS for e in events)}
    return page(request,journal,'learning',collect)


def review_page(request,journal):
    import learning_events as le
    def collect():
        legacy=le.list_to_review(limit=100000)
        rows=legacy['events']
        if journal.governed:
            for item in journal.list('memory',review=True):
                if item['state'] not in {'candidate','quarantined'}:continue
                p=item['payload'];event=le._make_event('bot_memory',item['id']+':'+str(item['revision']),'captured',le._to_utc(item['updated_at']),
                    lesson_id=item['id'],title=str(p.get('content') or 'Empty legacy record · review required'),
                    target={'kind':'memory','id':item['id'],'version':item['revision']},
                    source_refs=[{'kind':'memory','id':item['id'],'excerpt':str(p.get('content') or '')[:240]}],provenance='partial')
                event.update(governance=item['state'],journal_revision=item['revision'])
                rows.append(event)
        rows.sort(key=lambda e:(e['ts'],e['event_id']),reverse=True)
        coverage=legacy.get('coverage',{})
        complete=bool(coverage) and all(c.get('state') in {'ok','no_store','uninstrumented'} for c in coverage.values())
        return {'rows':rows,'complete':complete,'coverage':coverage,'window_start':None,'window_end':le.datetime.now(le.timezone.utc).isoformat()}
    return page(request,journal,'review',collect)
