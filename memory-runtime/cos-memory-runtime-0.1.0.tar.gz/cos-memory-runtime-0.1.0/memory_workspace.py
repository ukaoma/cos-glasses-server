"""Versioned owner-only workspace RPC: bounded graph paths and durable explorations.

No model is needed for graph traversal. Existing graph rows are undirected;
source dates, extraction timestamps and validity are never conflated.
"""
from __future__ import annotations
from collections import deque
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import time
import uuid
from memory_journal import MemoryJournal, JournalError, digest, now
from cos_atomic import atomic_write_json

PROTOCOL = 1
MAX_HOPS = 7
MAX_PATHS = 3
MAX_VISITED = 10000
MAX_EXPANSION = 25
MAX_NODES = 200
MAX_EDGES = 500
GRAPH_BUDGET_S = 3.0
MAX_REQUEST_BYTES = 512 * 1024
MAX_RESPONSE_BYTES = 900 * 1024
SEP = '<SEP>'


def index_path():
    explicit = os.environ.get('COS_GRAPH_INDEX_PATH')
    if explicit:
        from memory_generations import active_graph
        return active_graph(explicit)
    import lightrag_graph_index
    return lightrag_graph_index.index_path()


def base_generation():
    path = index_path()
    from memory_source_policy import grant_fingerprint
    scope=grant_fingerprint()
    try:
        stat = path.stat()
        return f'{stat.st_size}:{stat.st_mtime_ns}:{scope}'
    except OSError:
        return 'absent:'+scope


def overlay_generation(manifest):
    """Only graph evidence changes invalidate a pinned investigation.

    Saving a canvas, capturing a memory or adding a trace cannot change graph
    evidence. Source/identity/assertion revisions and deletion frontiers can.
    """
    if not manifest:return 'absent'
    return digest({'heads':{k:v for k,v in manifest['heads'].items()
                            if k.split(':',1)[0] in {'assertion','identity','source'}},
                   'deletion_epoch':manifest.get('deletion_epoch',0)})


class Graph:
    def __init__(self, journal):
        self.deadline = time.monotonic() + GRAPH_BUDGET_S
        self.journal = journal
        self.manifest = journal.manifest() if journal.available else None
        self.generation = {'base': base_generation(), 'overlay': overlay_generation(self.manifest),
                           'policy': self.manifest['policy']['revision'] if self.manifest else 1}
        path = index_path()
        self.conn = sqlite3.connect(f'file:{path}?mode=ro', uri=True) if path.is_file() else None
        if self.conn:
            self.conn.row_factory = sqlite3.Row
            from memory_source_policy import apply_graph_views
            apply_graph_views(self.conn,journal)
            self.conn.execute('BEGIN')
        from memory_identity import registry
        self.identity_registry=registry(journal)
        self.overlay = []
        if self.manifest:
            for key in sorted(self.manifest['heads']):
                if time.monotonic() >= self.deadline:
                    if self.conn: self.conn.close()
                    raise JournalError('graph_time_budget')
                if key.startswith('assertion:'):
                    value = journal.get('assertion', key[len('assertion:'):], manifest=self.manifest)
                    if value:
                        from memory_source_policy import payload_allowed
                        if payload_allowed(value['payload'],journal):self.overlay.append(value)
        self.exhaustive = True

    def close(self):
        if self.conn:self.conn.close()

    def check(self, expected=None):
        current = {'base': base_generation(), 'overlay': overlay_generation(self.journal.manifest() if self.journal.available else None),
                   'policy': self.journal.policy()['revision']}
        if current != self.generation or (expected and expected != self.generation):
            raise JournalError('generation_changed')

    def node(self, name):
        from memory_identity import resolve
        identity=resolve(name,self.journal,data=self.identity_registry)
        row = self.conn.execute('SELECT * FROM entities WHERE id=?', [name]).fetchone() if self.conn else None
        if row:
            return {'id': name, 'stable_id': identity['stable_id'],'identity_status':identity['status'],'canonical_id':identity['name'],
                    'type': row['type'] or 'unknown', 'group': row['type'] or 'unknown',
                    'description': str(row['description'] or '')[:1200], 'totalDegree': row['degree'],
                    'ts': row['created_at'], 'evidence_status': 'extracted', 'direction': 'undirected',
                    'validity': 'unknown'}
        if any(name in (x['payload']['source'], x['payload']['target']) for x in self.overlay):
            return {'id': name, 'type': 'concept', 'group': 'concept', 'description': 'User-authored exploration point.',
                    'evidence_status': 'user_authored', 'validity': 'unknown'}
        return None

    def neighbors(self, name, limit=2000, offset=0, *, direction='undirected', valid_at=None):
        overlays = []
        for value in self.overlay:
            p = value['payload']
            if name not in (p['source'], p['target']):continue
            if direction == 'directed' and (p.get('direction') != 'directed' or p['source'] != name):continue
            if valid_at and (not p.get('valid_from') or p['valid_from'] > valid_at or (p.get('valid_until') and p['valid_until'] < valid_at)):continue
            overlays.append({'id': value['id'], **p, 'weight': p.get('weight',1), 'evidence_status': 'user_authored',
                             'validity': 'known' if p.get('valid_from') else 'unknown', 'revision': value['revision']})
        edges = overlays[offset:offset + limit + 1]
        base_offset = max(0, offset - len(overlays))
        remaining = limit + 1 - len(edges)
        if remaining > 0 and self.conn and direction == 'undirected' and valid_at is None:
            rows = self.conn.execute('SELECT rowid,* FROM edges WHERE src=? UNION ALL SELECT rowid,* FROM edges WHERE tgt=? AND src!=? ORDER BY weight DESC,src,tgt LIMIT ? OFFSET ?',
                                     [name, name, name, remaining, base_offset]).fetchall()
            for r in rows:
                edges.append({'id': 'edge_' + digest([min(r['src'],r['tgt']),max(r['src'],r['tgt'])]),
                              'source': r['src'], 'target': r['tgt'], 'weight': r['weight'] or 1,
                              'description': str(r['description'] or '').split(SEP)[0][:240],
                              'direction': 'undirected', 'validity': 'unknown', 'evidence_status': 'extracted',
                              'evidence_refs': [x for x in str(r['source_ids'] or '').split(SEP) if x][:5],
                              'passage_query': {'source': r['src'], 'target': r['tgt']}})
        if len(edges) > limit: self.exhaustive = False
        if time.monotonic() >= self.deadline: raise JournalError('graph_time_budget')
        return edges[:limit]

    def expand(self, name, offset=0):
        node = self.node(name)
        if not node:raise JournalError('entity_not_found')
        edges = self.neighbors(name, MAX_EXPANSION, offset)
        names = list(dict.fromkeys([name]+[e['target'] if e['source']==name else e['source'] for e in edges]))
        return {'nodes': [n for x in names if (n:=self.node(x))], 'links': edges,
                'next_offset': offset + MAX_EXPANSION if not self.exhaustive else None,
                'generation': self.generation, 'scope': 'owner_full_index', 'truncated': not self.exhaustive}

    def overview(self, focus=None):
        """One bounded, policy-filtered first view. Never parse GraphML or run a model."""
        names=[]
        if focus and self.node(focus):
            names.append(focus)
            names.extend(n['id'] for n in self.expand(focus)['nodes'] if n['id']!=focus)
        if self.conn:
            names.extend(r[0] for r in self.conn.execute('SELECT id FROM entities ORDER BY degree DESC,id LIMIT 60'))
        for value in self.overlay[:60]:
            names.extend([value['payload']['source'],value['payload']['target']])
        names=list(dict.fromkeys(names))[:60]
        nodes=[n for name in names if (n:=self.node(name))]
        visible={n['id'] for n in nodes};links={}
        for name in names:
            for edge in self.neighbors(name,limit=25):
                if edge['source'] in visible and edge['target'] in visible:
                    links[edge['id']]=edge
                if len(links)>=180:break
            if len(links)>=180:break
        self.check()
        return {'nodes':nodes,'links':list(links.values()),'generation':self.generation,
                'scope':'owner_full_index','selection_description':'Overview of up to 60 connected people and ideas',
                'paths':[],'focus':focus if focus in visible else None}

    def resolve_canvas(self, nodes, links):
        if len(nodes)>MAX_NODES or len(links)>MAX_EDGES:raise JournalError('canvas_limit')
        resolved_nodes=[];resolved_links=[];changes=[]
        assertions={value['id']:value for value in self.overlay}
        for old in nodes:
            if old.get('evidence_status')=='hypothesis':resolved_nodes.append(old);continue
            current=self.node(_text(old.get('id')))
            if current:resolved_nodes.append(current)
            else:
                resolved_nodes.append({**old,'evidence_status':'missing','descs':['Endpoint is absent from the current generation. Saved evidence remains historical.'],'description':'Endpoint is absent from the current generation. Saved evidence remains historical.'})
                from memory_identity import resolve
                identity=resolve(old['id'],self.journal,data=self.identity_registry)
                resolved_nodes[-1]['identity']=identity
                changes.append({'kind':'endpoint_redirect' if identity['name']!=old['id'] else 'endpoint_missing','id':old['id'],'identity':identity})
        for old in links:
            if old.get('evidence_status')=='hypothesis':resolved_links.append(old);continue
            current=None
            if old.get('id') in assertions:
                value=assertions[old['id']];current={'id':value['id'],**value['payload'],'evidence_status':'user_authored','revision':value['revision']}
            elif self.conn and str(old.get('id','')).startswith('edge_'):
                source=_text(old.get('source'));target=_text(old.get('target'))
                row=self.conn.execute('SELECT * FROM edges WHERE (src=? AND tgt=?) OR (src=? AND tgt=?) LIMIT 1',[source,target,target,source]).fetchone()
                if row:current={'id':old['id'],'source':row['src'],'target':row['tgt'],'weight':row['weight'] or 1,
                                'description':str(row['description'] or '').split(SEP)[0][:240],'direction':'undirected','validity':'unknown',
                                'evidence_status':'extracted','evidence_refs':[x for x in str(row['source_ids'] or '').split(SEP) if x][:5],
                                'passage_query':{'source':row['src'],'target':row['tgt']}}
            if current:
                resolved_links.append(current)
                fields=('source','target','description','direction','evidence_refs','revision')
                if any(current.get(k)!=old.get(k) for k in fields):changes.append({'kind':'evidence_changed','id':current['id']})
            else:changes.append({'kind':'link_withdrawn','id':old.get('id')})
            if time.monotonic()>=self.deadline:raise JournalError('graph_time_budget')
        return {'nodes':resolved_nodes,'links':resolved_links,'changes':changes,'generation':self.generation,'scope':'owner_full_index'}

    def paths(self, start, target, waypoints=(), hops=3, avoid=(), direction='undirected', valid_at=None):
        if not 1 <= hops <= MAX_HOPS:raise JournalError('invalid_hop_budget')
        goals = list(waypoints) + [target]
        if len(set([start]+goals)) != len([start]+goals):raise JournalError('repeated_waypoint')
        if any(self.node(n) is None for n in [start]+goals):raise JournalError('entity_not_found')
        deadline = self.deadline
        queue = deque([([start], [], 0)])
        result = [];visited=0;cache={};reason=None
        while queue and len(result)<MAX_PATHS:
            if time.monotonic() >= deadline:reason='time_budget';break
            if visited>=MAX_VISITED:reason='work_budget';break
            nodes, links, next_goal = queue.popleft();visited+=1
            current = nodes[-1]
            if current == goals[next_goal]:
                next_goal+=1
                if next_goal == len(goals):
                    result.append({'id': 'path_'+digest([e['id'] for e in links]),'nodes':nodes,'edges':links});continue
            if len(links)>=hops:continue
            if current not in cache:cache[current]=self.neighbors(current, direction=direction, valid_at=valid_at)
            for edge in cache[current]:
                other=edge['target'] if edge['source']==current else edge['source']
                if other in nodes or other in avoid:continue
                if other in goals[next_goal+1:]:continue
                queue.append((nodes+[other],links+[edge],next_goal))
                if len(queue)>=MAX_VISITED:
                    reason='work_budget';break
            if reason:break
        if len(result)>=MAX_PATHS and queue:reason='path_limit'
        if not self.exhaustive:reason=reason or 'neighbor_budget'
        all_names=list(dict.fromkeys(x for path in result for x in path['nodes']))
        all_links={e['id']:e for path in result for e in path['edges']}
        return {'paths':result,'nodes':[self.node(x) for x in all_names], 'links':list(all_links.values()),
                'generation':self.generation,'hops':hops,'scope':'owner_full_index', 'visited':visited,
                'truncated':bool(reason),'truncation_reason':reason,'exhaustive':not reason,
                'message': 'Connections are associations, not proof of correlation or causation.' if result else
                           ('Search stopped at a limit; no path was found within this search.' if reason else 'No path within the selected hop and direction limits.'),
                'direction':direction,'valid_at':valid_at}


def investigate_plan(plan, allowed_names, generation, journal=None):
    """Execute only existing read-only graph controls; model text has no write authority."""
    if not isinstance(plan,dict) or set(plan)-{'anchors','waypoints','hops','direction','avoid','valid_at'}:
        raise JournalError('invalid_investigation_plan')
    anchors=plan.get('anchors',[]);waypoints=plan.get('waypoints',[]);avoid=plan.get('avoid',[])
    if not isinstance(anchors,list) or not 1<=len(anchors)<=2 or not isinstance(waypoints,list) or len(waypoints)>6 or not isinstance(avoid,list) or len(avoid)>20:
        raise JournalError('invalid_investigation_points')
    names=anchors+waypoints+avoid
    if any(not isinstance(n,str) or n not in allowed_names for n in names) or len(set(names))!=len(names):
        raise JournalError('unresolved_investigation_points')
    hops=plan.get('hops',3);direction=plan.get('direction','undirected');valid=plan.get('valid_at')
    if type(hops) is not int or not 3<=hops<=MAX_HOPS or direction not in {'undirected','directed'}:
        raise JournalError('invalid_investigation_filters')
    if valid is not None:
        from datetime import date
        try:date.fromisoformat(valid)
        except (ValueError,TypeError):raise JournalError('invalid_valid_date')
    if len(anchors)==1 and waypoints:raise JournalError('waypoints_need_two_anchors')
    if len(anchors)==1 and (direction!='undirected' or avoid or valid):raise JournalError('filtered_overview_unavailable')
    graph=Graph(journal or MemoryJournal())
    try:
        graph.check(generation)
        if any(graph.node(n) is None for n in names):raise JournalError('entity_not_found')
        result=graph.paths(anchors[0],anchors[1],waypoints,hops,avoid,direction,valid) if len(anchors)==2 else graph.expand(anchors[0])
        # A no-path result still shows the chosen endpoints, never a misleading blank canvas.
        have={n['id'] for n in result['nodes']}
        result['nodes'].extend(graph.node(n) for n in anchors+waypoints if n not in have)
        graph.check()
        return {**result,'status':'ready','anchors':anchors,'waypoints':waypoints,
                'filters':{'hops':hops,'direction':direction,'avoid':avoid,'valid_at':valid},
                'message':result.get('message','Showing the selected point and its known connections.')}
    finally:graph.close()


def _text(value, maximum=256):
    if not isinstance(value,str) or not value.strip() or len(value)>maximum:raise JournalError('invalid_text')
    return value.strip()


def _journal_for_write(journal):
    if not journal.available:
        # Existing corpora require a protected adoption; GUI writes cannot implicitly adopt them.
        if journal.governed:raise JournalError('journal_recovery_required')
        if not os.environ.get('COS_MEMORY_EMPTY_INSTANCE'):
            raise JournalError('journal_adoption_required')
        # Owner identity is supplied by local installation, never by RPC input.
        owner = os.environ.get('COS_INSTANCE_OWNER') or 'local-owner'
        journal.initialize(owner)
    return journal


def _memory_page(request, journal):
    from bot_memory import all_memory_records
    from memory_pages import page
    q=str(request.get('q','')).strip()[:500]
    def collect():
        rows=all_memory_records()
        if q:
            from bot_memory import search_memory, _salience_multiplier
            rows=search_memory(q,limit=max(1,len(rows)),salience_tiering=False)
            rows.sort(key=lambda r:(float(r.get('score',0))*_salience_multiplier(r),str(r.get('created_at','')),str(r.get('id',''))),reverse=True)
        else:
            rows.sort(key=lambda r:(str(r.get('created_at','')),str(r.get('id',''))),reverse=True)
        items=[{**{k:v for k,v in r.items() if k!='content'},'content':str(r.get('content',''))[:1200],
                'summary':str(r.get('content','') or '(empty legacy record — review required)')[:180]} for r in rows]
        return {'rows':items,'complete':True,'window_end':now(),'window_start':None,'source_as_of':now(),
                'policy_revision':journal.policy()['revision']}
    return page(request,journal,'memories',collect)


def dispatch(request, journal=None):
    if not isinstance(request,dict) or len(json.dumps(request).encode())>MAX_REQUEST_BYTES:raise JournalError('invalid_request')
    if any(key in request for key in ('owner','audience','actor','path','authority_host','authority_epoch')):
        raise JournalError('caller_authority_forbidden')
    from memory_protocol import validate
    validate(request)
    action=request.get('action');journal=journal or MemoryJournal()
    if action=='status':
        result={**journal.status(),'graph_available':index_path().is_file(),'capabilities':sorted(__import__('memory_protocol').FIELDS),
                'limits':{'hops':MAX_HOPS,'nodes':MAX_NODES,'edges':MAX_EDGES,'neighbors':MAX_EXPANSION,'paths':MAX_PATHS}}
    elif action in {'graph_overview','graph_expand','graph_paths','graph_resolve'}:
        graph=Graph(journal)
        try:
            graph.check(request.get('generation'))
            if action=='graph_overview':result=graph.overview(_text(request['focus']) if request.get('focus') else None)
            elif action=='graph_resolve':result=graph.resolve_canvas(request.get('nodes',[]),request.get('links',[]))
            elif action=='graph_expand':result=graph.expand(_text(request.get('id')),max(0,int(request.get('offset',0))))
            else:
                direction=request.get('direction','undirected')
                if direction not in {'directed','undirected'}:raise JournalError('invalid_direction')
                waypoints=request.get('waypoints',[]);avoid=request.get('avoid',[])
                if not isinstance(waypoints,list) or len(waypoints)>MAX_HOPS or not isinstance(avoid,list) or len(avoid)>MAX_NODES:raise JournalError('invalid_waypoints')
                result=graph.paths(_text(request.get('start')),_text(request.get('target')),[_text(x) for x in waypoints],
                                   int(request.get('hops',3)),[_text(x) for x in avoid],direction,request.get('valid_at'))
            graph.check()
        finally:graph.close()
    elif action in {'rule_page','propose_rule','review_rule','rollback_rule','activate_rule','rule_evaluation'}:
        from memory_stewardship import dispatch as stewardship
        result=stewardship(request,journal)
    elif action=='memory_page':result=_memory_page(request,journal)
    elif action=='learning_page':
        from memory_learning import learning_page
        result=learning_page(request,journal)
    elif action=='review_page':
        from memory_learning import review_page
        result=review_page(request,journal)
    elif action=='get_memory':
        item=journal.get('memory',_text(request.get('id')),review=True)
        if not item:raise JournalError('memory_not_found')
        result={'item':item}
    elif action=='review_memory':
        from memory_service import revise,forget
        record_id=_text(request.get('id'));decision=request.get('decision')
        if decision not in {'accept','quarantine','restore','forget'}:raise JournalError('invalid_decision')
        revision=request.get('expected_revision');key=_text(request.get('idempotency_key'))
        if decision=='forget':result=forget(record_id,expected_revision=revision,idempotency_key=key,journal=journal)
        else:
            current=journal.get('memory',record_id,review=True)
            if not current:raise JournalError('memory_not_found')
            target='quarantined' if decision=='quarantine' else 'active'
            result=revise(record_id,{'reviewed':'accepted' if target=='active' else 'quarantined','reviewed_by':'instance_owner'},
                          state=target,expected_revision=revision,idempotency_key=key,journal=journal)
            result['state']=target
    elif action=='trace_summary':
        from memory_trace import summary
        result=summary(journal)
    elif action=='source_status':
        from memory_sources import current_sources
        result={'items':[{'id':v['id'],'revision':v['revision'],**{k:v['payload'].get(k) for k in ('title','content_hash','captured_at','projection')}} for v in current_sources(journal)]}
    elif action=='refresh_source':
        from memory_sources import refresh_document
        result=refresh_document(_text(request.get('id')),expected_revision=request.get('expected_revision'),idempotency_key=_text(request.get('idempotency_key')),journal=journal)
    elif action=='current_sources':
        from memory_sources import current_answer
        result=current_answer(_text(request.get('q')),journal)
    elif action=='identity_status':
        from memory_identity import registry,blocked_pair,resolve
        source=_text(request.get('source'));target=_text(request.get('target'))
        writable=False
        if journal.available:
            try:journal._authority(journal.manifest());writable=True
            except JournalError:pass
        result={'revision':registry(journal)['revision'],'writable':writable,
                'blocked':blocked_pair(source,target,journal=journal),
                'same_identity':resolve(source,journal)['name']==resolve(target,journal)['name']}
    elif action=='identity_keep_apart':
        from memory_identity import keep_apart
        result=keep_apart(_text(request.get('source')),_text(request.get('target')),expected_revision=request.get('expected_revision'),
                          idempotency_key=_text(request.get('idempotency_key')),journal=_journal_for_write(journal))
    elif action=='identity_split_preview':
        from memory_identity import split_preview
        result=split_preview(_text(request.get('id')),journal)
    elif action=='policy_get':
        state='adoption_required';writable=False
        if journal.available:
            try:
                journal._authority(journal.manifest());writable=True;state='available'
            except JournalError as exc:state=str(exc)
        result={'policy':journal.policy(),'owner_only':True,'writable':writable,'state':state}
    elif action=='policy_set':
        result=_journal_for_write(journal).update_policy(request.get('changes',{}),expected_revision=request.get('expected_revision'),
                                                       idempotency_key=_text(request.get('idempotency_key')))
    elif action=='list_explorations':
        manifest=journal.manifest() if journal.available else {'heads':{},'generation':0}
        offset=0
        if request.get('cursor'):
            try:
                generation,offset=[int(x) for x in request['cursor'].split(':')]
                if generation!=manifest['generation'] or offset<0:raise ValueError()
            except (ValueError,TypeError):raise JournalError('cursor_restart_required')
        keys=sorted(k for k,h in manifest['heads'].items() if k.startswith('exploration:') and h['state']=='active')
        rows=[]
        for key in keys[offset:offset+25]:
            value=journal.get('exploration',key[len('exploration:'):],manifest=manifest)
            if value:rows.append({k:value[k] for k in ('id','revision','updated_at','operation_id')}|{'title':value['payload'].get('title','Untitled investigation')})
        result={'items':rows,'next_cursor':f"{manifest['generation']}:{offset+25}" if offset+25<len(keys) else None}
    elif action=='get_exploration':
        value=journal.get('exploration',_text(request.get('id'))) if journal.available else None
        if not value:raise JournalError('exploration_not_found')
        result={'item':value}
    elif action in {'save_exploration','save_assertion'}:
        _journal_for_write(journal)
        kind='exploration' if action=='save_exploration' else 'assertion'
        payload=request.get('payload')
        if not isinstance(payload,dict):raise JournalError('invalid_payload')
        if kind=='assertion':
            allowed={'source','target','description','relation_type','direction','valid_from','valid_until','evidence_refs'}
            if set(payload)-allowed:raise JournalError('invalid_assertion_fields')
            payload=dict(payload)
            payload['relation_type']=_text(payload.get('relation_type','associated_with'),100)
            payload['source']=_text(payload.get('source'));payload['target']=_text(payload.get('target'))
            payload['description']=_text(payload.get('description'),2000)
            if payload['source']==payload['target']:raise JournalError('self_association')
            if payload.get('direction','undirected') not in {'directed','undirected'}:raise JournalError('invalid_direction')
            from datetime import date
            for field in ('valid_from','valid_until'):
                if payload.get(field):
                    try:date.fromisoformat(payload[field])
                    except (ValueError,TypeError):raise JournalError('invalid_valid_date')
            if payload.get('valid_from') and payload.get('valid_until') and payload['valid_until']<payload['valid_from']:raise JournalError('invalid_valid_interval')
            refs=payload.get('evidence_refs',[])
            if not isinstance(refs,list) or len(refs)>10 or any(not isinstance(x,str) or len(x)>256 for x in refs):raise JournalError('invalid_evidence_refs')
            payload['source_status']='user_authored'
        else:
            allowed={'title','anchors','waypoints','nodes','links','positions','filters','generation','paths'}
            if set(payload)-allowed:raise JournalError('invalid_exploration_fields')
            from memory_protocol import validate_canvas
            validate_canvas(payload)
        result=_journal_for_write(journal).mutate(kind,_text(request.get('id')),payload,expected_revision=request.get('expected_revision',0),
                          idempotency_key=_text(request.get('idempotency_key')),state='active')
    else:raise JournalError('unsupported_workspace_action')
    result.update(protocol=PROTOCOL,request_id=request.get('request_id'))
    if len(json.dumps(result).encode())>MAX_RESPONSE_BYTES:raise JournalError('response_too_large')
    return result
