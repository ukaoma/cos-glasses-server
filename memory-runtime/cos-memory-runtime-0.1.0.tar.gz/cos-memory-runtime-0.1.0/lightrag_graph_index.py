"""Compatibility path resolver for the public explicit-link index (no LightRAG dependency)."""
import os
from pathlib import Path

def index_path():
    value=os.environ.get('COS_GRAPH_INDEX_PATH')
    if not value:raise ValueError('public_instance_not_configured')
    return Path(value)
