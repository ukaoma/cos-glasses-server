"""Explicit versioned source refresh, independent of ordinary meeting dedup.

Source IDs resolve through an owner-maintained registry; RPC callers cannot
supply filesystem paths. Current answers can cite immutable passage snapshots
without reusing blended legacy graph descriptions.
"""
import hashlib
import json
import os
from pathlib import Path
import re
from memory_journal import MemoryJournal,JournalError,digest,now

REGISTRY=Path(os.environ.get('COS_MEMORY_SOURCE_REGISTRY') or Path(__file__).parent/'.memory_source_registry.json')
MAX_SOURCE_BYTES=4*1024*1024

def registry():
    try:data=json.loads(REGISTRY.read_text())
    except FileNotFoundError:return {'schema':1,'sources':{}}
    except (OSError,ValueError) as exc:raise JournalError('source_registry_invalid') from exc
    if data.get('schema')!=1 or not isinstance(data.get('sources'),dict):raise JournalError('source_registry_invalid')
    return data

def resolve(source_id):
    entry=registry()['sources'].get(source_id)
    if not entry:raise JournalError('source_not_granted')
    path=Path(entry['path']).expanduser().resolve(strict=True)
    grant=Path(entry.get('grant_root') or path.parent).expanduser().resolve(strict=True)
    if path!=grant and grant not in path.parents:raise JournalError('source_grant_changed')
    if entry.get('resolved_path') and str(path)!=entry['resolved_path']:raise JournalError('source_link_target_changed')
    if not path.is_file() or path.stat().st_size>MAX_SOURCE_BYTES:raise JournalError('source_size_or_type_invalid')
    return entry,path

def refresh_document(source_id,*,expected_revision,idempotency_key,journal=None):
    journal=journal or MemoryJournal()
    manifest=journal.manifest();journal._authority(manifest)
    request={'source_id':source_id,'expected_revision':expected_revision}
    operation_id=digest({'corpus':manifest['corpus_id'],'key':idempotency_key})
    prior=manifest.get('committed_operations',{}).get(operation_id)
    if prior:
        original=json.loads(journal._blob(prior['blob']).read_text())
        if prior['record_key']!='source:'+source_id or original['payload'].get('refresh_request')!=request:
            raise JournalError('idempotency_conflict')
        return {**prior,'source_id':source_id,'content_hash':original['payload']['content_hash'],'status':'refreshed'}
    entry,path=resolve(source_id)
    # One byte snapshot; extraction below only uses that snapshot.
    raw=path.read_bytes()
    if len(raw)>MAX_SOURCE_BYTES:raise JournalError('source_too_large')
    text=raw.decode('utf-8');content_hash=hashlib.sha256(raw).hexdigest()
    previous=journal.get('source',source_id,review=True)
    if previous and previous['payload']['content_hash']==content_hash and previous['payload'].get('resolved_path')==str(path) and set(entry.get('legacy_doc_ids',[]))<=set(previous['payload'].get('legacy_doc_ids',[])) and set(entry.get('legacy_chunk_ids',[]))<=set(previous['payload'].get('legacy_chunk_ids',[])):
        return {'status':'unchanged','source_id':source_id,'revision':previous['revision'],'content_hash':content_hash,'operation_id':previous['operation_id']}
    if (previous['revision'] if previous else 0)!=expected_revision:raise JournalError('revision_conflict')
    # Source-backed passage projection succeeds independently of optional model extraction.
    passages=[]
    for line_start in range(0,len(text.splitlines()),40):
        body='\n'.join(text.splitlines()[line_start:line_start+40])
        if body.strip():passages.append({'id':'passage_'+digest([source_id,content_hash,line_start]),'line':line_start+1,'text':body,
                                         'source_id':source_id,'content_hash':content_hash,'evidence_status':'verbatim'})
    legacy_docs=set(entry.get('legacy_doc_ids',[]));legacy_chunks=set(entry.get('legacy_chunk_ids',[]))
    from memory_workspace import index_path
    import sqlite3
    index=index_path()
    if index.is_file():
        from memory_source_policy import path_matches
        with sqlite3.connect(index.as_uri()+'?mode=ro',uri=True) as conn:
            for row in conn.execute('SELECT doc_id,source_key FROM docs'):
                if path_matches(row[1],str(path)) or row[1]==source_id:legacy_docs.add(row[0])
            for doc in legacy_docs:
                legacy_chunks.update(row[0] for row in conn.execute('SELECT chunk_id FROM chunks WHERE doc_id=?',[doc]))
    payload={'source_id':source_id,'kind':entry.get('kind','document'),'title':entry.get('title') or path.name,
             'content_hash':content_hash,'content':text,'passages':passages,'source_event_time':entry.get('source_event_time'),
             'captured_at':now(),'source_mtime_ns':path.stat().st_mtime_ns,'source_status':'verbatim',
             'legacy_doc_ids':sorted(legacy_docs|set((previous or {}).get('payload',{}).get('legacy_doc_ids',[]))),
             'legacy_chunk_ids':sorted(legacy_chunks|set((previous or {}).get('payload',{}).get('legacy_chunk_ids',[]))),
             'projection':'validated_passages','prior_revision':expected_revision,'refresh_request':request,
             'legacy_paths':sorted(set((previous or {}).get('payload',{}).get('legacy_paths',[]))|set(x for x in [(previous or {}).get('payload',{}).get('resolved_path'),entry['path']] if x)),
             'resolved_path':str(path),'grant_root':str(Path(entry.get('grant_root') or path.parent).expanduser().resolve())}
    receipt=journal.mutate('source',source_id,payload,expected_revision=expected_revision,idempotency_key=idempotency_key)
    return {**receipt,'source_id':source_id,'content_hash':content_hash,'passages':len(passages),'status':'refreshed'}

def current_sources(journal=None):
    journal=journal or MemoryJournal()
    if journal.governed:journal.manifest()
    from memory_generations import binding
    pointer=binding(journal.state_root);replica=(pointer or {}).get('replica')
    if replica:
        manifest=journal.manifest()
        if any(replica.get(k)!=manifest.get(k) for k in ('owner','corpus_id','authority_host','authority_epoch')):raise JournalError('replica_grant_identity_mismatch')
        granted=set(replica.get('source_ids',[]))
        proof_path=journal.state_root/'replica-authority.json'
        if not proof_path.is_file():raise JournalError('replica_frontier_unavailable')
        proof=json.loads(proof_path.read_text())
        if proof.get('checksum')!=digest({k:v for k,v in proof.items() if k!='checksum'}) or any(proof.get(k)!=manifest.get(k) for k in ('owner','corpus_id','authority_host','authority_epoch')):raise JournalError('replica_frontier_invalid')
        granted &= set(proof['source_ids'])
        return [row for row in journal.list('source') if row['id'] in granted]
    visible=[]
    for value in journal.list('source') if journal.available else []:
        try:
            entry,path=resolve(value['id'])
            if value['payload'].get('resolved_path')!=str(path):continue
        except (JournalError,OSError):continue
        visible.append(value)
    return visible

def current_answer(query,journal=None,limit=6):
    words=set(re.findall(r'[a-z0-9]{3,}',query.casefold()));matches=[]
    for source in current_sources(journal):
        payload=source['payload']
        for passage in payload['passages']:
            score=len(words&set(re.findall(r'[a-z0-9]{3,}',passage['text'].casefold())))
            if score:matches.append((score,source['revision'],{**passage,'title':payload['title'],'revision':source['revision'],'captured_at':payload['captured_at']}))
    matches.sort(key=lambda x:(-x[0],-x[1],x[2]['id']))
    return {'query':query,'items':[x[2] for x in matches[:limit]],'scope':'current_source_snapshots','synthesis':'verbatim_passages_only'}

def excluded_chunks(journal=None):
    chunks=set();docs=set()
    visible={row['id'] for row in current_sources(journal)}
    journal=journal or MemoryJournal()
    if journal.governed:journal.manifest()
    # Revoking a source must not re-enable its contaminated legacy projection.
    for value in journal.list('source') if journal.available else []:
        chunks.update(value['payload'].get('legacy_chunk_ids',[]));docs.update(value['payload'].get('legacy_doc_ids',[]))
        if value['id'] not in visible:
            chunks.update(p['id'] for p in value['payload'].get('passages',[]));docs.add(value['id'])
    return chunks,docs

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('action',choices=['refresh_document','query','status']);p.add_argument('source_or_query',nargs='?',default='');p.add_argument('--expected-revision',type=int,default=0);p.add_argument('--idempotency-key')
    args=p.parse_args()
    try:
        if args.action=='refresh_document':result=refresh_document(args.source_or_query,expected_revision=args.expected_revision,idempotency_key=args.idempotency_key or digest([args.source_or_query,args.expected_revision]))
        elif args.action=='query':result=current_answer(args.source_or_query)
        else:result={'sources':[{k:r['payload'].get(k) for k in ['source_id','title','content_hash','captured_at']} for r in current_sources()]}
        print(json.dumps(result))
    except (JournalError,OSError,ValueError) as exc:
        print(json.dumps({'error':str(exc)}));raise SystemExit(1)
