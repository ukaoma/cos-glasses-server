"""Local evaluator attestations. Model output and uploaded JSON cannot sign checks.

The key belongs to the instance owner outside distributable data. This boundary
protects the RPC/artifact path; it does not protect against a process already able
to modify the owner's private files or execute arbitrary local code.
"""
import hashlib
import hmac
import json
import os
from memory_journal import MemoryJournal,JournalError,digest


def attest(kind,value,journal=None):
    journal=journal or MemoryJournal();path=journal.state_root/'evaluation-key'
    with journal.locked():
        if not path.exists():
            fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
            with os.fdopen(fd,'wb') as stream:stream.write(os.urandom(32));stream.flush();os.fsync(stream.fileno())
        key=path.read_bytes()
    return hmac.new(key,(kind+':'+digest(value)).encode(),hashlib.sha256).hexdigest()


def verify(kind,value,signature,journal=None):
    journal=journal or MemoryJournal();path=journal.state_root/'evaluation-key'
    if not path.is_file() or not isinstance(signature,str):raise JournalError('trusted_evaluation_receipt_required')
    expected=hmac.new(path.read_bytes(),(kind+':'+digest(value)).encode(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,signature):raise JournalError('trusted_evaluation_receipt_mismatch')
    return True
