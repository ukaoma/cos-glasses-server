"""Bounded subprocess ownership. A top-level operation owns one process group.

Nested providers inherit that group. The outer supervisor cleans remaining
members even if the immediate child exits first. Never kill by executable name.
"""
from __future__ import annotations
import os
import signal
import subprocess
import threading
import selectors
import time


class OutputLimitExceeded(RuntimeError):
    """The child exceeded the bounded output contract; its group is stopped."""


def _communicate_bounded(process, value, timeout):
    deadline=time.monotonic()+timeout if timeout is not None else None
    data=value.encode(process.stdin.encoding or 'utf-8') if isinstance(value,str) else value or b''
    if len(data)>64*1024*1024:raise OutputLimitExceeded('stdin_limit_exceeded')
    output={'stdout':bytearray(),'stderr':bytearray()};limits={'stdout':64*1024*1024,'stderr':8*1024*1024}
    with selectors.DefaultSelector() as selector:
        for name in ('stdout','stderr'):
            stream=getattr(process,name)
            if stream is not None:
                os.set_blocking(stream.fileno(),False);selector.register(stream,selectors.EVENT_READ,name)
        offset=0
        if process.stdin is not None:
            if data:
                os.set_blocking(process.stdin.fileno(),False);selector.register(process.stdin,selectors.EVENT_WRITE,'stdin')
            else:process.stdin.close()
        while selector.get_map():
            remaining=deadline-time.monotonic() if deadline is not None else None
            if remaining is not None and remaining<=0:raise subprocess.TimeoutExpired(process.args,timeout)
            for key,_ in selector.select(min(0.1,remaining) if remaining is not None else 0.1):
                stream=key.fileobj;name=key.data
                if name=='stdin':
                    try:offset+=os.write(stream.fileno(),data[offset:offset+65536])
                    except BrokenPipeError:offset=len(data)
                    except BlockingIOError:continue
                    if offset==len(data):selector.unregister(stream);stream.close()
                else:
                    try:chunk=os.read(stream.fileno(),65536)
                    except BlockingIOError:continue
                    if not chunk:selector.unregister(stream);continue
                    if len(output[name])+len(chunk)>limits[name]:raise OutputLimitExceeded(name+'_limit_exceeded')
                    output[name].extend(chunk)
    remaining=max(0,deadline-time.monotonic()) if deadline is not None else None
    process.wait(timeout=remaining)
    result=[]
    for name in ('stdout','stderr'):
        stream=getattr(process,name)
        if stream is None:result.append(None)
        else:
            raw=bytes(output[name]);encoding=getattr(stream,'encoding',None)
            result.append(raw.decode(encoding,errors=getattr(stream,'errors','strict')).replace('\r\n','\n').replace('\r','\n') if encoding else raw)
    return result


def run_supervised(args, *, input=None, capture_output=True, text=True, timeout=None, env=None, cwd=None):
    child_env = dict(os.environ if env is None else env)
    owns_group = child_env.get('COS_PROCESS_SCOPE') != '1'
    child_env['COS_PROCESS_SCOPE'] = '1'
    process = subprocess.Popen(args, stdin=subprocess.PIPE if input is not None else None,
                               stdout=subprocess.PIPE if capture_output else None,
                               stderr=subprocess.PIPE if capture_output else None,
                               text=text, env=child_env, cwd=cwd, start_new_session=owns_group)
    previous = {}
    def terminate(signum=None, frame=None):
        try:
            if owns_group:
                os.killpg(process.pid, signal.SIGTERM)
            elif process.poll() is None:
                process.terminate()
        except ProcessLookupError:
            pass
        if signum is not None:
            raise InterruptedError('operation_cancelled')
    # SIGTERM from an outer bridge reaches the owned group through this handler.
    if threading.current_thread() is threading.main_thread():
        for sig in (signal.SIGTERM, signal.SIGINT):
            previous[sig] = signal.getsignal(sig)
            signal.signal(sig, terminate)
    try:
        stdout, stderr = _communicate_bounded(process, input, timeout)
        return subprocess.CompletedProcess(args, process.returncode, stdout, stderr)
    except (subprocess.TimeoutExpired, BaseException):
        terminate()
        try:
            process.wait(timeout=.5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=1)
        raise
    finally:
        if owns_group:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        for sig, handler in previous.items():
            signal.signal(sig, handler)
        for handle in (process.stdin, process.stdout, process.stderr):
            if handle:
                handle.close()
