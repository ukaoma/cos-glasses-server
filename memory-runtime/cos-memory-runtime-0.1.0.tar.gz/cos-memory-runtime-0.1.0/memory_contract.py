"""Instance-local opt-out marker; no shared system-wide temporary files."""
import os
from pathlib import Path

def automatic_memory_opted_out():
    return (Path(os.environ['COS_MEMORY_STATE_DIR'])/'no-store').exists()

def validate_capture(content,admission):
    import re
    rules={'min_words':6,'min_distinct_chars':8,'max_repeat_ratio':0.5,'banned_patterns':[r'^\W*lorem ipsum',r'^\W*test(ing)?\b',r'^(.)\1{20,}$'],**admission}
    text=content.strip()
    if len(text.split())<rules['min_words'] or len(set(text.casefold()))<rules['min_distinct_chars'] or max(text.count(c) for c in set(text))/len(text)>rules['max_repeat_ratio']:
        raise ValueError('capture_admission_rejected')
    if any(re.search(pattern,text,re.IGNORECASE) for pattern in rules['banned_patterns']):raise ValueError('capture_admission_rejected')
