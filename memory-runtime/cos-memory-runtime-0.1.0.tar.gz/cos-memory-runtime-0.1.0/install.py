#!/usr/bin/env python3
"""Provision or upgrade a public runtime without replacing its instance data."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import uuid
import venv
ROOT=Path(__file__).resolve().parent

def install(data_root):
    manifest=json.loads((ROOT/'bundle.json').read_text())
    if manifest.get('protocol')!=1:raise ValueError('unsupported_bundle_protocol')
    for relative,sha in manifest['files'].items():
        path=ROOT/relative
        if Path(relative).is_absolute() or '..' in Path(relative).parts or path.is_symlink():raise ValueError('unsafe_bundle_member')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=sha:raise ValueError('bundle_checksum_mismatch: '+relative)
    path=ROOT/'instance.json'
    if path.exists():
        config=json.loads(path.read_text())
        if Path(config['data_root']).resolve()!=data_root:raise ValueError('existing_instance_data_root_differs')
    else:
        config={'schema':1,'owner':'owner_'+uuid.uuid4().hex,'data_root':str(data_root)}
        path.write_text(json.dumps(config,indent=2));path.chmod(0o600)
    data_root.mkdir(parents=True,exist_ok=True,mode=0o700)
    if not (ROOT/'venv/bin/python3').exists():venv.EnvBuilder(with_pip=False).create(ROOT/'venv')
    from runtime_config import configure
    configure()
    from memory_journal import MemoryJournal
    journal=MemoryJournal()
    if journal.governed:journal.manifest();journal.checkpoint()
    else:journal.initialize(config['owner'])
    return {'status':'ready','protocol':1,'scripts_directory':str(ROOT),'data_root':str(data_root),
            'memory_search':'keyword','graph':'explicit_document_links_and_user_assertions',
            'models':'none_required','instance_owner':config['owner']}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,required=True);args=p.parse_args()
    print(json.dumps(install(args.data_root.expanduser().resolve())))
