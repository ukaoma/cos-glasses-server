#!/usr/bin/env python3
"""Versioned public bridge entry point. All inputs are local owner requests."""
import json
import sys
from runtime_config import configure
configure()
from memory_journal import MemoryJournal,JournalError,digest

def main():
    command=sys.argv[1] if len(sys.argv)>1 else ''
    journal=MemoryJournal()
    if command=='memory-workspace':
        from memory_workspace import dispatch,MAX_REQUEST_BYTES
        raw=sys.stdin.buffer.read(MAX_REQUEST_BYTES+1)
        if len(raw)>MAX_REQUEST_BYTES:raise JournalError('request_too_large')
        request=json.loads(raw);result=dispatch(request,journal)
        if request.get('action')=='refresh_source':
            from source_index import build
            try:result['graph_projection']=build(journal)
            except (OSError,ValueError) as exc:result.update(status='source_refreshed_pending_graph',projection_error=str(exc))
        return result
    if command in {'memory-guardrails','memory-guardrails-run'}:
        import argparse,memory_guardrails
        parser=argparse.ArgumentParser();parser.add_argument('--stdin',action='store_true');parser.add_argument('--days',type=int,default=30);parser.add_argument('--apply',action='store_true');parser.add_argument('--llm',action='store_true');args=parser.parse_args(sys.argv[2:])
        if command=='memory-guardrails-run':
            if not 1<=args.days<=36500:raise JournalError('invalid_review_window')
            return memory_guardrails.run(days=args.days,apply=args.apply,llm=args.llm)
        rules=memory_guardrails.write_guardrails(json.loads(sys.stdin.buffer.read(65537))) if args.stdin else memory_guardrails.read_guardrails()
        return {'guardrails':rules,'philosophy_rubric_lines':0}
    if command=='memory-detail':
        value=journal.get('memory',sys.argv[2])
        if not value:raise JournalError('memory_not_found')
        return {**value['payload'],'id':value['id'],'created_at':value['created_at'],'journal_revision':value['revision']}
    if command=='learning-event':
        import argparse
        import learning_events
        parser=argparse.ArgumentParser();parser.add_argument('--id',required=True);args=parser.parse_args(sys.argv[2:])
        row=next((r for r in learning_events._collect(3650).events if r['event_id']==args.id),None)
        if not row:raise JournalError('event_not_found')
        memory=journal.get('memory',row['lesson_id'],review=True) if row.get('lesson_id') else None
        return {'protocol':1,**row,'detail':{'content':memory['payload'].get('content','') if memory else ''}}
    if command in {'memory','memory-recent','memory-list'}:
        from bot_memory import all_memory_records
        import argparse
        from datetime import datetime, timedelta, timezone
        parser=argparse.ArgumentParser();parser.add_argument('--days',type=int,default=1);parser.add_argument('--limit',type=int,default=5)
        args=parser.parse_args(sys.argv[2:])
        if not 1<=args.days<=36500 or not 1<=args.limit<=500:raise JournalError('invalid_memory_window')
        cutoff=datetime.now(timezone.utc)-timedelta(days=args.days)
        rows=[]
        for row in all_memory_records():
            try:stamp=datetime.fromisoformat(row['created_at'].replace('Z','+00:00'))
            except (ValueError,KeyError):continue
            if stamp.tzinfo is None:continue
            if stamp>=cutoff:rows.append(row)
        return sorted(rows,key=lambda r:(r['created_at'],r['id']),reverse=True)[:args.limit]
    if command=='memory-overview':
        rows=journal.list('memory');by_type={}
        for row in rows:
            kind=row['payload'].get('type','unknown');by_type[kind]=by_type.get(kind,0)+1
        return {'available':True,'collection':'owner_journal','total':len(rows),'by_type':by_type}
    if command=='memory-status':return journal.status()
    if command=='context-learning-graph-status':
        from source_index import status
        return {'protocol':1,'learning':{'available':True,'state':'ok','to_review':sum(r['state']=='candidate' for r in journal.list('memory',review=True))},'graph':status(journal)}
    if command=='context-status':
        return {'available':True,'protocol':1,'memory':{'available':True,'total':len(journal.list('memory'))},'threads':{'available':False}}
    if command=='learning-status':
        from memory_learning import learning_page
        return learning_page({'days':90,'limit':1},journal)
    if command in {'graph-search','graph-entity','graph-passages'}:
        import argparse
        import graph_context
        parser=argparse.ArgumentParser();parser.add_argument('--q');parser.add_argument('--id');parser.add_argument('--entity');parser.add_argument('--relation-a');parser.add_argument('--relation-b');parser.add_argument('--limit',type=int,default=25);parser.add_argument('--offset',type=int,default=0);parser.add_argument('--type');args=parser.parse_args(sys.argv[2:])
        if command=='graph-search':result=graph_context.search(args.q or '',limit=args.limit,offset=args.offset,type=args.type)
        elif command=='graph-entity':result=graph_context.entity(args.id,offset=args.offset,limit=args.limit)
        else:result=graph_context.passages(entity=args.entity,relation_a=args.relation_a,relation_b=args.relation_b,limit=min(5,args.limit))
        return {**result,'protocol':1}
    if command=='memory-capture':
        raw=sys.stdin.buffer.read(65537)
        if len(raw)>65536:raise JournalError('request_too_large')
        data=json.loads(raw)
        if set(data)-{'id','content','source_refs','idempotency_key','session_id'}:raise JournalError('unsupported_capture_fields')
        content=data.get('content')
        if not isinstance(content,str) or not 30<=len(content)<=30000:raise JournalError('invalid_capture_content')
        from memory_contract import automatic_memory_opted_out,validate_capture
        if automatic_memory_opted_out():return {'status':'suppressed'}
        request_hash=digest(data)
        op=digest({'corpus':journal.manifest()['corpus_id'],'key':data['idempotency_key']})
        prior=journal.manifest().get('committed_operations',{}).get(op)
        if prior:
            if prior.get('caller_request_hash')!=request_hash:raise JournalError('idempotency_conflict')
            return prior
        from memory_sources import current_sources
        granted={r['id']:r for r in current_sources(journal)};versions=[]
        refs=data.get('source_refs',[])
        if not isinstance(refs,list) or len(refs)>30:raise JournalError('invalid_source_refs')
        for ref in refs:
            source_id=ref if isinstance(ref,str) else ref.get('id') if isinstance(ref,dict) else None
            source=granted.get(source_id)
            if not source:raise JournalError('source_reference_not_current_or_granted')
            versions.append({'source_id':source_id,'revision':source['revision'],'content_hash':source['payload']['content_hash']})
        validate_capture(content,journal.policy().get('admission',{}))
        return journal.mutate('memory',data['id'],{'id':data['id'],'content':content,'source_refs':refs,'source_versions':versions},expected_revision=0,idempotency_key=data['idempotency_key'],automatic=True,session_id=data.get('session_id'),caller_request_hash=request_hash)
    if command=='graph-status':
        from memory_workspace import Graph
        graph=Graph(journal)
        try:
            return {'protocol':1,'engine':'explicit_document_links','entities':graph.conn.execute('SELECT COUNT(*) FROM entities').fetchone()[0] if graph.conn else 0,
                    'relationships':graph.conn.execute('SELECT COUNT(*) FROM edges').fetchone()[0] if graph.conn else 0,
                    'index_state':__import__('source_index').status(journal)['index_state'],'source':{'is_owner':True,'owner_state':'owner','owner_host':__import__('socket').gethostname()},
                    'processor':{'state':'none'},'queue':{'pending':0},'generation':graph.generation}
        finally:graph.close()
    raise JournalError('capability_not_available_in_public_file_runtime')

if __name__=='__main__':
    try:print(json.dumps(main()))
    except (JournalError,OSError,ValueError,KeyError,TypeError) as exc:print(json.dumps({'error':str(exc),'retryable':False}))
