"""Workspace request contract. Unknown authority/scope fields never silently disappear."""
from datetime import date
from memory_journal import JournalError
COMMON={'action','request_id'}
FIELDS={
    'status':set(),'policy_get':set(),'policy_set':{'changes','expected_revision','idempotency_key'},
    'memory_page':{'q','limit','cursor'},'learning_page':{'days','limit','cursor'},'review_page':{'limit','cursor'},
    'get_memory':{'id'},'review_memory':{'id','decision','expected_revision','idempotency_key'},
    'graph_expand':{'id','offset','generation'},'graph_resolve':{'nodes','links'},
    'graph_paths':{'start','target','waypoints','hops','avoid','direction','valid_at','generation'},
    'list_explorations':{'cursor'},'get_exploration':{'id'},
    'save_exploration':{'id','payload','expected_revision','idempotency_key'},
    'save_assertion':{'id','payload','expected_revision','idempotency_key'},
    'rule_page':{'cursor','limit'},'propose_rule':{'payload'},
    'review_rule':{'id','expected_revision','idempotency_key'},'rollback_rule':{'id','expected_revision','idempotency_key'},
    'activate_rule':{'id','expected_revision','idempotency_key','evaluation_id'},'rule_evaluation':{'id','evaluation_id'},
    'trace_summary':set(),'source_status':set(),'refresh_source':{'id','expected_revision','idempotency_key'},
    'current_sources':{'q'},'identity_split_preview':{'id'},
    'identity_status':{'source','target'},'identity_keep_apart':{'source','target','expected_revision','idempotency_key'},
}

def validate(request):
    if not isinstance(request,dict):raise JournalError('invalid_request')
    action=request.get('action')
    if action not in FIELDS:raise JournalError('unsupported_workspace_action')
    if set(request)-COMMON-FIELDS[action]:raise JournalError('unsupported_request_fields_or_scope')
    for key in ('expected_revision','limit','offset','hops','days'):
        if key in request and (type(request[key]) is not int or request[key]<0):raise JournalError('invalid_'+key)
    for key in ('cursor','request_id','idempotency_key'):
        if request.get(key) is not None and (not isinstance(request[key],str) or len(request[key])>300):raise JournalError('invalid_'+key)
    if request.get('valid_at'):
        try:date.fromisoformat(request['valid_at'])
        except (TypeError,ValueError):raise JournalError('invalid_valid_date')
    if 'generation' in request and request['generation'] is not None:
        gen=request['generation']
        if not isinstance(gen,dict) or set(gen)!={'base','overlay','policy'}:raise JournalError('invalid_generation')
    if action in {'graph_resolve'}:
        if not isinstance(request.get('nodes'),list) or not isinstance(request.get('links'),list):raise JournalError('invalid_canvas')

def validate_canvas(payload):
    """Validate stored canvas structure before it reaches a future renderer."""
    import math
    def text(value):return isinstance(value,str) and 0<len(value)<=1000
    nodes=payload.get('nodes',[]);links=payload.get('links',[])
    if not isinstance(nodes,list) or not isinstance(links,list) or len(nodes)>200 or len(links)>500:raise JournalError('invalid_canvas')
    if any(not isinstance(n,dict) or not text(n.get('id')) for n in nodes):raise JournalError('invalid_canvas_node')
    ids=[n['id'] for n in nodes]
    if len(ids)!=len(set(ids)):raise JournalError('duplicate_canvas_node')
    for node in nodes:
        for key in ('x','y','fx','fy','vx','vy'):
            value=node.get(key)
            if value is not None and (type(value) not in (int,float) or not math.isfinite(value)):raise JournalError('invalid_canvas_position')
    for edge in links:
        if not isinstance(edge,dict) or not text(edge.get('source')) or not text(edge.get('target')):raise JournalError('invalid_canvas_edge')
        if edge['source'] not in ids or edge['target'] not in ids:raise JournalError('canvas_endpoint_missing')
        if edge.get('direction','undirected') not in {'directed','undirected','unknown'}:raise JournalError('invalid_canvas_direction')
    if not isinstance(payload.get('title',''),str) or len(payload.get('title',''))>500:raise JournalError('invalid_canvas_title')
    anchors=payload.get('anchors',[]);waypoints=payload.get('waypoints',[])
    if not isinstance(anchors,list) or len(anchors)>2 or any(a is not None and not text(a) for a in anchors):raise JournalError('invalid_canvas_anchors')
    if not isinstance(waypoints,list) or len(waypoints)>6 or any(not text(w) for w in waypoints) or len(set(waypoints))!=len(waypoints) or set(waypoints)&set(anchors):raise JournalError('invalid_canvas_waypoints')
    filters=payload.get('filters',{})
    if not isinstance(filters,dict) or set(filters)-{'hops','direction','avoid','valid_at'}:raise JournalError('invalid_canvas_filters')
    if type(filters.get('hops',3)) is not int or not 3<=filters.get('hops',3)<=7:raise JournalError('invalid_canvas_hops')
    if filters.get('direction','undirected') not in {'directed','undirected'}:raise JournalError('invalid_canvas_direction')
    avoid=filters.get('avoid',[])
    if not isinstance(avoid,list) or len(avoid)>200 or any(not text(v) for v in avoid):raise JournalError('invalid_canvas_avoid')
    if filters.get('valid_at'):
        try:date.fromisoformat(filters['valid_at'])
        except (ValueError,TypeError):raise JournalError('invalid_valid_date')
    positions=payload.get('positions',{})
    if not isinstance(positions,dict) or len(positions)>200:raise JournalError('invalid_canvas_positions')
    for key,values in positions.items():
        if not text(key) or not isinstance(values,dict) or set(values)-{'x','y','fx','fy'}:raise JournalError('invalid_canvas_position')
        if any(v is not None and (type(v) not in (int,float) or not math.isfinite(v)) for v in values.values()):raise JournalError('invalid_canvas_position')
    paths=payload.get('paths',[])
    if not isinstance(paths,list) or len(paths)>3:raise JournalError('invalid_canvas_paths')
    for path in paths:
        if not isinstance(path,dict) or not isinstance(path.get('nodes'),list) or not isinstance(path.get('edges'),list) or len(path['nodes'])>8 or len(path['edges'])>7 or any(not text(n) for n in path['nodes']) or any(not isinstance(e,dict) or not text(e.get('source')) or not text(e.get('target')) for e in path['edges']):raise JournalError('invalid_canvas_path')
