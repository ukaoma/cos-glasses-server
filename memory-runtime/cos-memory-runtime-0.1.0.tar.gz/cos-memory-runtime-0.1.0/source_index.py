"""Deterministic document-link graph. No inferred relation is labeled as a fact."""
import os
from pathlib import Path
import re
import sqlite3
import tempfile
from memory_journal import MemoryJournal,sync_directory
from memory_sources import current_sources

def build(journal=None):
    journal=journal or MemoryJournal();target=__import__('memory_generations').active_graph(os.environ['COS_GRAPH_INDEX_PATH']);target.parent.mkdir(parents=True,exist_ok=True)
    with journal.locked():
        generation=journal.manifest()['generation'];sources=current_sources(journal)
        fd,tmp=tempfile.mkstemp(prefix='.graph-',suffix='.sqlite',dir=target.parent);os.close(fd)
        try:
            with sqlite3.connect(tmp) as conn:
                conn.executescript('''CREATE TABLE entities(id TEXT PRIMARY KEY,type TEXT,degree INTEGER,description TEXT,created_at INTEGER,source_ids TEXT);
CREATE TABLE edges(src TEXT,tgt TEXT,weight REAL,description TEXT,created_at INTEGER,source_ids TEXT);
CREATE INDEX edges_src ON edges(src,weight);CREATE INDEX edges_tgt ON edges(tgt,weight);
CREATE TABLE chunks(chunk_id TEXT PRIMARY KEY,doc_id TEXT,chunk_order_index INTEGER,content TEXT);
CREATE TABLE docs(doc_id TEXT PRIMARY KEY,source_key TEXT,source_title TEXT,source_date TEXT);
CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT);''')
                nodes={};edges=[]
                for row in sources:
                    p=row['payload'];doc_id=row['id']+'@'+str(row['revision']);title=p['title'];nodes.setdefault(title,{'refs':set(),'degree':0})
                    conn.execute('INSERT INTO docs VALUES(?,?,?,?)',[doc_id,row['id'],title,row['updated_at']])
                    for i,passage in enumerate(p['passages']):
                        conn.execute('INSERT INTO chunks VALUES(?,?,?,?)',[passage['id'],doc_id,i,passage['text']]);nodes[title]['refs'].add(passage['id'])
                        for linked in sorted(set(re.findall(r'\[\[([^\]\n|]{1,200})(?:\|[^\]\n]*)?\]\]',passage['text']))):
                            linked=linked.strip()
                            if not linked or linked==title:continue
                            nodes.setdefault(linked,{'refs':set(),'degree':0})['refs'].add(passage['id'])
                            edges.append((title,linked,1,'Explicit document link; no causal claim',None,passage['id']))
                            nodes[title]['degree']+=1;nodes[linked]['degree']+=1
                conn.executemany('INSERT INTO entities VALUES(?,?,?,?,?,?)',[(name,'document',value['degree'],'Explicitly referenced document or idea.',None,'<SEP>'.join(sorted(value['refs']))) for name,value in nodes.items()])
                conn.executemany('INSERT INTO edges VALUES(?,?,?,?,?,?)',edges)
                conn.execute('INSERT INTO meta VALUES(?,?)',['journal_generation',str(generation)])
                from memory_journal import digest
                conn.execute('INSERT INTO meta VALUES(?,?)',['sources_hash',digest([(r['id'],r['revision']) for r in sources])])
                if conn.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('index_integrity_failed')
            with open(tmp,'rb') as f:os.fsync(f.fileno())
            os.replace(tmp,target);sync_directory(target.parent)
            return {'status':'indexed','entities':len(nodes),'relationships':len(edges),'generation':generation}
        finally:Path(tmp).unlink(missing_ok=True)


def status(journal=None):
    """An existing file is not proof that it contains the current granted sources."""
    from memory_journal import digest
    journal = journal or MemoryJournal()
    target = __import__('memory_generations').active_graph(os.environ['COS_GRAPH_INDEX_PATH'])
    if not target.is_file():
        return {'available': False, 'state': 'missing', 'index_state': 'missing'}
    try:
        with sqlite3.connect(f'file:{target}?mode=ro', uri=True) as conn:
            stored = conn.execute("SELECT value FROM meta WHERE key='sources_hash'").fetchone()
        expected = digest([(row['id'], row['revision']) for row in current_sources(journal)])
        fresh = bool(stored and stored[0] == expected)
        return {'available': True, 'state': 'ok' if fresh else 'stale',
                'index_state': 'fresh' if fresh else 'stale', 'refresh_required': not fresh}
    except (OSError, sqlite3.Error, ValueError):
        return {'available': False, 'state': 'unreadable', 'index_state': 'unreadable'}
