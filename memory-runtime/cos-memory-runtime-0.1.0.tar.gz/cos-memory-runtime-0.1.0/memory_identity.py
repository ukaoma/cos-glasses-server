"""Additive stable identities, redirects and source-level split previews."""
import hashlib
import json
from memory_journal import MemoryJournal,JournalError,digest

def stable_id(name):return 'entity_'+hashlib.sha256(name.encode()).hexdigest()

def registry(journal=None):
    journal=journal or MemoryJournal()
    if not journal.governed:return {'entries':{},'constraints':[],'revision':0}
    value=journal.get('identity','registry')
    return {**value['payload'],'revision':value['revision']} if value else {'entries':{},'constraints':[],'revision':0}

def resolve(name,journal=None,*,data=None):
    entries=(data if data is not None else registry(journal))['entries'];seen=set();name=str(name)
    if name not in entries:
        name=next((key for key,value in entries.items() if value.get('stable_id')==name),name)
    while name in entries and entries[name].get('redirect'):
        if name in seen:raise JournalError('identity_redirect_cycle')
        seen.add(name);name=entries[name]['redirect']
    entry=entries.get(name,{})
    return {'name':name,'stable_id':entry.get('stable_id',stable_id(name)),
            'status':entry.get('status','unverified'),'aliases':sorted(seen|set(entry.get('aliases',[]))),'evidence_refs':entry.get('evidence_refs',[])}

def members(name,journal=None):
    value=resolve(name,journal);return set(value['aliases'])|{name,value['name']}

def blocked_pair(a,b,known_different=(),journal=None):
    data=registry(journal)
    left=members(a,journal);right=members(b,journal)
    for name in left|right:
        entry=data['entries'].get(name,{})
        if entry.get('status')=='ambiguous' or resolve(name,journal,data=data)['status']=='ambiguous':
            return f'{name} represents unresolved identities; review source-specific assignments before merging.'
    norm=lambda x:' '.join(x.casefold().split())
    denied={frozenset((norm(x),norm(y))) for x,y in [*known_different,*data['constraints']]}
    if any(frozenset((norm(x),norm(y))) in denied for x in left for y in right):
        return 'Merge group contains identities explicitly kept apart.'
    return None

def mark_ambiguous(name,evidence_refs,*,expected_revision,idempotency_key,journal=None):
    journal=journal or MemoryJournal()
    request={'name':name,'evidence_refs':evidence_refs,'expected_revision':expected_revision}
    with journal.locked():
        manifest=journal.manifest();journal._authority(manifest)
        operation_id=digest({'corpus':manifest['corpus_id'],'key':idempotency_key})
        prior=manifest.get('committed_operations',{}).get(operation_id)
        if prior:
            original=json.loads(journal._blob(prior['blob']).read_text())
            if prior['record_key']!='identity:registry' or original['payload'].get('ambiguity_request')!=request:
                raise JournalError('idempotency_conflict')
            return prior
        data=registry(journal)
        if data['revision']!=expected_revision:raise JournalError('revision_conflict')
        data.pop('revision');old=data['entries'].get(name,{})
        data['ambiguity_request']=request
        data['entries'][name]={**old,'stable_id':old.get('stable_id',stable_id(name)),'status':'ambiguous','evidence_refs':old.get('evidence_refs',[])+evidence_refs,'aliases':old.get('aliases',[])}
        return journal._mutate_locked('identity','registry',data,expected_revision=expected_revision,idempotency_key=idempotency_key)

def record_merge(source,target,*,ticket,known_different=(),journal=None,_lock_held=False):
    journal=journal or MemoryJournal()
    if not journal.governed:return {'status':'not_instrumented'}
    manifest=journal.manifest();operation_id=digest({'corpus':manifest['corpus_id'],'key':'identity_merge:'+ticket})
    prior=manifest.get('committed_operations',{}).get(operation_id)
    request={'source':source,'target':target,'ticket':ticket}
    if prior:
        original=json.loads(journal._blob(prior['blob']).read_text())
        if original['payload'].get('merge_request')!=request:raise JournalError('idempotency_conflict')
        return prior
    reason=blocked_pair(source,target,known_different,journal)
    if reason:raise JournalError(reason)
    data=registry(journal);revision=data.pop('revision')
    data['merge_request']=request
    canonical=resolve(target,journal);aliases=members(source,journal)|members(target,journal)
    proof={'kind':'merge_receipt','id':ticket}
    target_entry=dict(data['entries'].get(target,{}))
    target_entry.pop('redirect',None)
    evidence=[]
    for name in aliases:
        for ref in data['entries'].get(name,{}).get('evidence_refs',[]):
            if ref not in evidence:evidence.append(ref)
    if proof not in evidence:evidence.append(proof)
    data['entries'][target]={**target_entry,'stable_id':target_entry.get('stable_id',canonical['stable_id']),'status':'reviewed_alias','aliases':sorted(aliases-{target}),'evidence_refs':evidence}
    for name in aliases-{target}:
        old=data['entries'].get(name,{})
        refs=old.get('evidence_refs',[])
        data['entries'][name]={**old,'stable_id':old.get('stable_id',stable_id(name)),'redirect':target,'status':'redirect','evidence_refs':refs+[proof] if proof not in refs else refs}
    mutate=journal._mutate_locked if _lock_held else journal.mutate
    return mutate('identity','registry',data,expected_revision=revision,idempotency_key='identity_merge:'+ticket)

def split_preview(name,journal=None):
    import graph_context
    evidence=graph_context.passages(entity=name,limit=20)
    return {'identity':resolve(name,journal),'source_assignments':evidence,'mutation':False,
            'next_step':'Assign source passages to distinct identities before a reviewed split. No source is reassigned by this preview.'}


def keep_apart(source, target, *, expected_revision, idempotency_key, journal=None):
    """Persist an owner-reviewed constraint across all aliases in both groups."""
    journal = journal or MemoryJournal()
    if not all(isinstance(n, str) and 0 < len(n.strip()) <= 200 for n in (source, target)):
        raise JournalError('invalid_entity')
    source, target = source.strip(), target.strip()
    request = {'source': source, 'target': target, 'expected_revision': expected_revision}
    with journal.locked():
        manifest = journal.manifest(); journal._authority(manifest)
        operation_id = digest({'corpus': manifest['corpus_id'], 'key': idempotency_key})
        prior = manifest.get('committed_operations', {}).get(operation_id)
        if prior:
            original = json.loads(journal._blob(prior['blob']).read_text())
            if prior['record_key'] != 'identity:registry' or original['payload'].get('constraint_request') != request:
                raise JournalError('idempotency_conflict')
            return prior
        data = registry(journal)
        if data['revision'] != expected_revision:
            raise JournalError('revision_conflict')
        left, right = resolve(source, journal, data=data), resolve(target, journal, data=data)
        if left['name'] == right['name']:
            raise JournalError('identity_split_required')
        data.pop('revision')
        data['constraint_request'] = request
        pair = sorted([left['name'], right['name']])
        if pair not in [sorted(p) for p in data['constraints']]: data['constraints'].append(pair)
        return journal._mutate_locked('identity', 'registry', data, expected_revision=expected_revision, idempotency_key=idempotency_key)
