"""Read cited public document links from the configured SQLite projection."""
import os
import sqlite3
from pathlib import Path

def passages(entity=None,relation_a=None,relation_b=None,limit=5,**kwargs):
    from memory_generations import active_graph
    path=active_graph(os.environ['COS_GRAPH_INDEX_PATH'])
    if not path.is_file():return {'items':[],'total':0}
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as conn:
        conn.row_factory=sqlite3.Row
        if relation_a and relation_b:
            ids=conn.execute('SELECT source_ids FROM edges WHERE (src=? AND tgt=?) OR (src=? AND tgt=?)',[relation_a,relation_b,relation_b,relation_a]).fetchall()
        else:ids=conn.execute('SELECT source_ids FROM entities WHERE id=?',[entity]).fetchall()
        chunks=set(x for row in ids for x in str(row['source_ids']).split('<SEP>') if x)
        rows=[]
        from memory_sources import current_sources
        allowed={r['id']+'@'+str(r['revision']):r for r in current_sources()}
        for chunk in sorted(chunks):
            row=conn.execute('SELECT * FROM chunks WHERE chunk_id=?',[chunk]).fetchone()
            if row and row['doc_id'] in allowed:
                source=allowed[row['doc_id']]
                for passage in source['payload']['passages']:
                    if passage['id']==chunk:rows.append({'chunk_id':passage['id'],'doc_id':source['id'],'order':passage['line'],'excerpt':passage['text'][:1200],'source':{'key':source['id'],'title':source['payload']['title'],'status':'resolved','date':source['updated_at']}})
        return {'items':rows[:limit],'total':len(rows),'scope':'current_granted_sources'}

def search(q,limit=30,offset=0,**kwargs):
    from memory_workspace import Graph
    from memory_journal import MemoryJournal
    graph=Graph(MemoryJournal())
    try:
        if not graph.conn:return {'items':[],'total':0,'index_state':'missing'}
        limit=max(1,min(int(limit),30));offset=max(0,int(offset));entity_type=kwargs.get('type')
        names=graph.conn.execute('SELECT id FROM entities WHERE instr(lower(id),lower(?))>0 AND (? IS NULL OR type=?) ORDER BY id',[q,entity_type,entity_type]).fetchall()
        return {'items':[{**graph.node(r[0]),'degree':graph.node(r[0]).get('totalDegree',0)} for r in names[offset:offset+limit]],'total':len(names),'offset':offset,'limit':limit,'index_state':__import__('source_index').status()['index_state'],'matcher':'keyword','scope':'current_granted_sources'}
    finally:graph.close()

def entity(name,offset=0,limit=25):
    from memory_workspace import Graph
    from memory_journal import MemoryJournal
    graph=Graph(MemoryJournal())
    try:
        from memory_journal import JournalError
        if not graph.node(name):raise JournalError('entity_not_found')
        limit=max(1,min(int(limit),30));offset=max(0,int(offset))
        edges=graph.neighbors(name,limit,offset)
        names=list(dict.fromkeys([name]+[e['target'] if e['source']==name else e['source'] for e in edges]))
        result={'links':edges,'nodes':[graph.node(n) for n in names],'next_offset':offset+limit if not graph.exhaustive else None}
        node=graph.node(name)
        total=graph.conn.execute('SELECT COUNT(*) FROM edges WHERE src=? OR tgt=?',[name,name]).fetchone()[0] if graph.conn else 0
        total+=sum(name in (row['payload']['source'],row['payload']['target']) for row in graph.overlay)
        return {**node,'degree':total,'description_length':len(node.get('description','')),'descriptions':[node.get('description','')],'total_relationships':total,'limit':limit,'source_status':'resolved','index_state':__import__('source_index').status()['index_state'],'found':True,'neighbors':[n for n in result['nodes'] if n['id']!=name],'edges':result['links'],'offset':offset,'has_more':result['next_offset'] is not None}
    finally:graph.close()
