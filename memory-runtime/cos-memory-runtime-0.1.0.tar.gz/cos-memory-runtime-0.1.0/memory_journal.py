"""Owner-only durable memory journal and rebuildable graph exploration overlay.

The existing corpus remains authoritative until explicit initialization/adoption.
Readers never initialize a store. JSON generations, blobs and operation receipts
are durable; projections must not be used as the only copy of an assertion.
"""
from __future__ import annotations
from contextlib import contextmanager
import copy
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import tempfile
import uuid
from cos_atomic import atomic_write_json

SCHEMA = 1
READER = 1
KINDS = {'memory', 'assertion', 'exploration', 'source', 'identity', 'policy', 'trace', 'rule'}
STATES = {'candidate', 'active', 'quarantined', 'superseded', 'deleted'}
DEFAULT_POLICY = {'capture_enabled': True, 'review_required': True, 'automatic_curation': False,
                  'no_store_sessions': [], 'admission': {}, 'revision': 1}

class JournalError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)

def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()

def default_root():
    return Path(os.environ.get('COS_MEMORY_JOURNAL_DIR') or Path(__file__).parent / '.memory_journal')

def sync_directory(path):
    fd = os.open(path, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)

import contextvars
_expected_authority = contextvars.ContextVar('cos_expected_memory_authority', default=None)

@contextmanager
def pinned_authority(identity):
    """Carry a verified transport pin to the final fenced commit, never via payload."""
    token = _expected_authority.set(dict(identity))
    try:yield
    finally:_expected_authority.reset(token)

class MemoryJournal:
    def __init__(self, root=None, state_root=None, *, _recovery=False):
        self.logical_root = Path(root or default_root()).resolve()
        identity = hashlib.sha256(str(self.logical_root).encode()).hexdigest()[:20]
        self.state_root = Path(state_root or os.environ.get('COS_MEMORY_STATE_DIR') or Path.home() / 'Library/Application Support/COS Memory' / identity).resolve()
        from memory_generations import binding
        self._recovery=_recovery
        try:pointer = binding(self.state_root)
        except JournalError:
            if not _recovery:raise
            from memory_generations import recovery_binding
            pointer=recovery_binding(self.state_root,self.logical_root)
        self.root = Path(pointer['journal']) if pointer else self.logical_root
        self.manifest_path = self.root / 'manifest.json'
        self.checkpoint_path = self.state_root / 'deletions.json'
        self.reader_floor_path = self.state_root / 'reader-floor.json'

    @property
    def available(self):
        return self.manifest_path.is_file()

    @property
    def governed(self):
        return self.available or self.reader_floor_path.exists() or self.checkpoint_path.exists()

    def manifest(self):
        from memory_generations import binding
        pointer=binding(self.state_root) if not self._recovery else {'journal':str(self.root)}
        expected=Path(pointer['journal']) if pointer else self.logical_root
        if self.root!=expected:raise JournalError('serving_generation_changed_retry')
        try:
            data = json.loads(self.manifest_path.read_text())
        except (OSError, ValueError) as exc:
            raise JournalError('journal_unavailable') from exc
        if data.get('schema') != SCHEMA or data.get('min_reader', 999) > READER:
            raise JournalError('unsupported_journal_schema')
        return data

    @contextmanager
    def locked(self):
        self.state_root.mkdir(parents=True, exist_ok=True, mode=0o700)
        with (self.state_root / 'writer.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(lock, fcntl.LOCK_UN)

    def _write(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        atomic_write_json(path, value, durable=True)
        path.chmod(0o600)

    def initialize(self, owner, *, corpus_id=None):
        with self.locked():
            return self._initialize_locked(owner, corpus_id=corpus_id)

    def _initialize_locked(self, owner, *, corpus_id=None):
        if not owner or not isinstance(owner, str):raise JournalError('owner_required')
        intent_path=self.state_root/'initialization-intent.json'
        if self.available:
            manifest=self.manifest()
            if manifest['owner']!=owner or (corpus_id is not None and manifest['corpus_id']!=corpus_id):raise JournalError('initialization_identity_mismatch')
            if intent_path.is_file():
                intent=json.loads(intent_path.read_text());intent['completed']=True;intent.pop('checksum',None)
                self._write(intent_path,{**intent,'checksum':digest(intent)})
            return manifest
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        if intent_path.is_file():
            try:
                intent=json.loads(intent_path.read_text());manifest=intent['manifest']
                if intent.get('checksum')!=digest({k:v for k,v in intent.items() if k!='checksum'}) or intent.get('completed') or intent.get('root')!=str(self.root):raise ValueError()
                if manifest['owner']!=owner or manifest['authority_host']!=socket.gethostname() or (corpus_id is not None and corpus_id!=manifest['corpus_id']):raise ValueError()
                if manifest.get('generation')!=0 or manifest.get('heads')!={} or manifest.get('adopted') is not False:raise ValueError()
                if any((self.root/name).exists() for name in ('blobs','operations','projections')):raise ValueError()
            except (OSError,ValueError,KeyError,TypeError) as exc:raise JournalError('initialization_recovery_requires_inspection') from exc
        else:
            if self.governed:raise JournalError('journal_recovery_required')
            manifest = {'schema': SCHEMA, 'min_reader': READER, 'corpus_id': corpus_id or uuid.uuid4().hex,
                    'owner': owner, 'authority_host': socket.gethostname(), 'authority_epoch': 1,
                    'generation': 0, 'deletion_epoch': 0, 'heads': {}, 'committed_operations': {}, 'policy': copy.deepcopy(DEFAULT_POLICY),
                    'created_at': now(), 'updated_at': now(), 'adopted': False}
            intent={'schema':1,'root':str(self.root),'manifest':manifest,'completed':False}
            self._write(intent_path,{**intent,'checksum':digest(intent)})
        checkpoint={'corpus_id':manifest['corpus_id'],'epoch':0,'tombstones':{}}
        if self.checkpoint_path.exists():
            if self.checkpoint()!={**checkpoint,'checksum':digest(checkpoint)}:raise JournalError('initialization_frontier_changed')
        else:self._write_checkpoint(checkpoint)
        floor={'schema':SCHEMA,'min_reader':READER,'corpus_id':manifest['corpus_id'],'root':str(self.root)}
        if self.reader_floor_path.exists():
            if json.loads(self.reader_floor_path.read_text())!=floor:raise JournalError('initialization_reader_floor_changed')
        else:self._write(self.reader_floor_path,floor)
        self._write(self.manifest_path, manifest)
        intent['completed']=True;intent.pop('checksum',None)
        self._write(intent_path,{**intent,'checksum':digest(intent)})
        return manifest

    def _authority(self, manifest):
        expected = _expected_authority.get()
        if expected is not None and any(expected.get(k) != manifest.get(k) for k in ('owner','corpus_id','authority_host','authority_epoch')):
            raise JournalError('pending_authority_mismatch')
        if self._recovery:raise JournalError('recovery_handle_readonly')
        if manifest.get('authority_host') != socket.gethostname() or not manifest.get('authority_epoch'):
            raise JournalError('not_memory_authority')
        return self.checkpoint(manifest)

    def _write_checkpoint(self, checkpoint):
        value = {k:v for k,v in checkpoint.items() if k != 'checksum'}
        self._write(self.checkpoint_path, {**value, 'checksum': digest(value)})

    def checkpoint(self, manifest=None):
        if not self.checkpoint_path.is_file():
            raise JournalError('deletion_frontier_unavailable')
        try:
            checkpoint = json.loads(self.checkpoint_path.read_text())
            raw = {k:v for k,v in checkpoint.items() if k != 'checksum'}
            valid = checkpoint.get('checksum') == digest(raw) and isinstance(checkpoint['tombstones'],dict) and isinstance(checkpoint['epoch'],int)
        except (OSError, ValueError, KeyError, TypeError):
            valid = False
        if not valid:
            raise JournalError('deletion_frontier_corrupt')
        if manifest and (checkpoint.get('corpus_id') != manifest['corpus_id'] or checkpoint.get('epoch', -1) < manifest.get('deletion_epoch', 0)):
            raise JournalError('deletion_frontier_mismatch')
        return checkpoint

    def policy(self):
        return dict(self.manifest()['policy']) if self.governed else copy.deepcopy(DEFAULT_POLICY)

    def key(self, kind, record_id):
        if kind not in KINDS or not isinstance(record_id, str) or not 1 <= len(record_id) <= 256:
            raise JournalError('invalid_record_identity')
        return kind + ':' + record_id

    def _blob(self, name):
        if not isinstance(name, str) or len(name) != 64 or any(c not in '0123456789abcdef' for c in name):
            raise JournalError('invalid_blob_reference')
        return self.root / 'blobs' / (name + '.json')

    def get(self, kind, record_id, *, review=False, manifest=None):
        m = manifest or self.manifest()
        key = self.key(kind, record_id)
        if key in self.checkpoint(m)['tombstones']:
            return None
        head = m['heads'].get(key)
        if not head or head['state'] == 'deleted' or (not review and head['state'] != 'active'):
            return None
        path = self._blob(head['blob'])
        try:
            value = json.loads(path.read_text())
        except (OSError, ValueError) as exc:
            raise JournalError('journal_blob_missing_or_corrupt') from exc
        if digest(value) != head['blob']:
            raise JournalError('journal_blob_checksum_mismatch')
        if value.get('owner') != m['owner'] or value.get('audience') != [m['owner']] or value.get('id') != record_id or value.get('kind') != kind or value.get('revision') != head['revision']:
            raise JournalError('journal_blob_identity_mismatch')
        if kind=='memory' and not review:
            from memory_source_policy import payload_allowed,lineage
            if not payload_allowed(value['payload'],self,policy=lineage(self,manifest=m)):return None
        return value

    def _purge(self, key):
        kind, record_id = key.split(':', 1)
        root = self.root / 'blobs'
        for path in root.glob('*.json'):
            row = json.loads(path.read_text())
            if row.get('kind') == kind and row.get('id') == record_id:
                path.unlink()
        if root.exists(): sync_directory(root)
        if kind == 'memory':
            projections = self.root / 'projections'
            for path in projections.glob('*.json'):
                value=json.loads(path.read_text())
                if value.get('id') == record_id and value.get('kind') != 'delete': path.unlink()
            if projections.exists(): sync_directory(projections)
            pages=self.state_root/'pages'
            if pages.exists():
                shutil.rmtree(pages)
                sync_directory(self.state_root)

    def _finish(self, receipt):
        if receipt.get('state') == 'deleted':
            self._purge(receipt['record_key'])
        self._write(self.root / 'operations' / (receipt['operation_id'] + '.json'), receipt)
        return receipt

    def list(self, kind, *, review=False):
        manifest = self.manifest()
        rows = []
        for key in manifest['heads']:
            if key.startswith(kind + ':'):
                value = self.get(kind, key[len(kind)+1:], review=review, manifest=manifest)
                if value is not None:
                    rows.append(value)
        return rows

    def mutate(self, kind, record_id, payload, *, expected_revision, idempotency_key,
               state='active', actor=None, session_id=None, automatic=False, projection=None, caller_request_hash=None):
        key = self.key(kind, record_id)
        if state not in STATES or not isinstance(payload, dict) or not idempotency_key:
            raise JournalError('invalid_mutation')
        with self.locked():
            return self._mutate_locked(kind,record_id,payload,expected_revision=expected_revision,idempotency_key=idempotency_key,
                state=state,actor=actor,session_id=session_id,automatic=automatic,projection=projection,caller_request_hash=caller_request_hash)

    def _mutate_locked(self, kind, record_id, payload, *, expected_revision, idempotency_key,
               state='active', actor=None, session_id=None, automatic=False, projection=None, caller_request_hash=None):
        key = self.key(kind, record_id)
        if state not in STATES or not isinstance(payload, dict) or not idempotency_key:
            raise JournalError('invalid_mutation')
        manifest = self.manifest()
        checkpoint = self._authority(manifest)
        if actor is not None and actor != manifest['owner']:
            raise JournalError('owner_mismatch')
        policy = manifest['policy']
        request_hash = digest({'key': key, 'payload': payload, 'state': state, 'expected': expected_revision,
                               'session_id': session_id, 'automatic': automatic,'caller_request_hash':caller_request_hash})
        operation_id = digest({'corpus': manifest['corpus_id'], 'key': idempotency_key})
        operation_path = self.root / 'operations' / (operation_id + '.json')
        committed = manifest.get('committed_operations', {}).get(operation_id)
        if committed:
            if committed['request_hash'] != request_hash:
                raise JournalError('idempotency_conflict')
            return self._finish(committed)
        if operation_path.exists():
            receipt = json.loads(operation_path.read_text())
            if receipt['request_hash'] != request_hash:
                raise JournalError('idempotency_conflict')
            if receipt.get('status') == 'suppressed':
                return receipt
            if receipt.get('status') == 'committed':
                return self._finish(receipt)
            # The manifest is the commit point; recover a receipt interrupted afterward.
            head = manifest['heads'].get(key, {})
            if head.get('operation_id') == operation_id:
                receipt.update(status='committed', generation=manifest['generation'], revision=head['revision'])
                return self._finish(receipt)
        if automatic and (not policy['capture_enabled'] or session_id in policy.get('no_store_sessions', [])):
            receipt = {'operation_id':operation_id, 'request_hash':request_hash, 'caller_request_hash':caller_request_hash, 'record_key':key,
                       'status':'suppressed', 'reason':'no_store', 'policy_revision':policy['revision'], 'created_at':now()}
            self._write(operation_path, receipt)
            return receipt
        if kind in {'memory','assertion'} and automatic and state == 'active' and policy['review_required']:
            state = 'candidate'
        old = manifest['heads'].get(key)
        revision = old['revision'] if old else 0
        if key in checkpoint['tombstones'] and state != 'deleted':
            raise JournalError('forgotten_record')
        if expected_revision != revision:
            raise JournalError('revision_conflict')
        receipt = {'operation_id': operation_id, 'request_hash': request_hash, 'caller_request_hash': caller_request_hash, 'record_key': key,
                   'status': 'intent', 'state': state, 'created_at': now(), 'revision': revision + 1}
        self._write(operation_path, receipt)
        if projection is not None:
            if kind != 'memory' or not isinstance(projection, dict):raise JournalError('invalid_projection')
            self._write(self.root / 'projections' / (operation_id + '.json'),
                        {**projection, 'id':record_id, 'operation_id':operation_id})
        value = {'id': record_id, 'kind': kind, 'revision': revision + 1, 'state': state,
                 'owner': manifest['owner'], 'audience': [manifest['owner']], 'payload': copy.deepcopy(payload),
                 'created_at': old.get('created_at', now()) if old else now(), 'updated_at': now(),
                 'policy_revision': policy['revision'], 'operation_id': operation_id,
                 'source_status': payload.get('source_status', 'user_authored' if not automatic else 'extracted')}
        blob = digest(value)
        if state != 'deleted':
            self._write(self._blob(blob), value)
        manifest['heads'][key] = {'revision': revision + 1, 'state': state, 'blob': blob if state != 'deleted' else None,
                                  'operation_id': operation_id, 'created_at': value['created_at'],
                                  'point_id': (projection or {}).get('point_id', (old or {}).get('point_id'))}
        manifest['generation'] += 1
        manifest['updated_at'] = now()
        if kind == 'policy':
            if manifest['policy']['revision'] != payload['expected_policy_revision']:
                raise JournalError('revision_conflict')
            manifest['policy'] = {**manifest['policy'], **payload['changes'], 'revision': manifest['policy']['revision'] + 1}
        if state == 'deleted':
            checkpoint['epoch'] += 1
            checkpoint['tombstones'][key] = revision + 1
            manifest['deletion_epoch'] = checkpoint['epoch']
            self._write_checkpoint(checkpoint)
        # Recheck the fence directly before committing the new generation.
        current = self.manifest()
        if current['authority_epoch'] != manifest['authority_epoch'] or current['authority_host'] != socket.gethostname():
            raise JournalError('authority_changed')
        receipt.update(status='committed', generation=manifest['generation'], committed_at=now(), blob=blob if state!='deleted' else None)
        manifest.setdefault('committed_operations', {})[operation_id] = receipt.copy()
        self._write(self.manifest_path, manifest)
        return self._finish(receipt)

    def update_policy(self, changes, *, expected_revision, idempotency_key):
        allowed = set(DEFAULT_POLICY) - {'revision'}
        if set(changes) - allowed:
            raise JournalError('unknown_policy_setting')
        for key, value in changes.items():
            if key == 'admission':
                from memory_guardrails import validate_patch
                if not isinstance(value,dict) or validate_patch(value)!=value:raise JournalError('invalid_admission_policy')
            elif key == 'no_store_sessions':
                if not isinstance(value, list) or any(not isinstance(x, str) for x in value):
                    raise JournalError('invalid_policy')
            elif not isinstance(value, bool):
                raise JournalError('invalid_policy')
        receipt = self.mutate('policy', 'effective', {'changes': changes, 'expected_policy_revision': expected_revision},
                             expected_revision=expected_revision - 1, idempotency_key=idempotency_key)
        return {'policy': self.policy(), 'receipt': receipt}

    @staticmethod
    def validate_snapshot(snapshot):
        src=Path(snapshot).resolve()
        spec=json.loads((src/'snapshot.json').read_text())
        if spec.get('schema')!=SCHEMA or 'manifest.json' not in spec.get('files',{}):raise JournalError('incomplete_snapshot')
        actual={str(p.relative_to(src)) for p in src.rglob('*') if p.is_file() and p!=src/'snapshot.json'}
        if actual!=set(spec['files']) or any(p.is_symlink() for p in src.rglob('*')):raise JournalError('snapshot_member_mismatch')
        for relative,expected in spec['files'].items():
            path=src/relative
            if Path(relative).is_absolute() or '..' in Path(relative).parts or src not in path.resolve().parents:raise JournalError('unsafe_snapshot_member')
            if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise JournalError('snapshot_checksum_mismatch')
        manifest=json.loads((src/'manifest.json').read_text())
        if manifest.get('corpus_id')!=spec.get('corpus_id') or manifest.get('generation')!=spec.get('generation') or manifest.get('min_reader',999)>READER:raise JournalError('snapshot_identity_mismatch')
        return spec

    def snapshot(self, destination):
        dest=Path(destination).resolve()
        if dest==self.root or self.root in dest.parents or dest.exists():raise JournalError('invalid_snapshot_destination')
        dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        with self.locked():
            manifest=self.manifest();checkpoint=self._authority(manifest)
            if any(p.is_symlink() for p in self.root.rglob('*')):raise JournalError('unsafe_snapshot_member')
            stage=Path(tempfile.mkdtemp(prefix='.memory-snapshot-',dir=dest.parent))
            try:
                shutil.copytree(self.root,stage,dirs_exist_ok=True,symlinks=False)
                files={}
                for path in stage.rglob('*'):
                    if path.is_file():
                        with path.open('rb') as stream:os.fsync(stream.fileno())
                        files[str(path.relative_to(stage))]=hashlib.sha256(path.read_bytes()).hexdigest()
                self._write(stage/'snapshot.json',{'schema':SCHEMA,'corpus_id':manifest['corpus_id'],
                    'generation':manifest['generation'],'deletion_epoch':checkpoint['epoch'],'files':files})
                self.validate_snapshot(stage)
                for directory in sorted((p for p in stage.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):sync_directory(directory)
                sync_directory(stage);os.replace(stage,dest);sync_directory(dest.parent)
            finally:
                if stage.exists():shutil.rmtree(stage)
        return dest

    def restore(self, snapshot, destination):
        src = Path(snapshot).resolve();dest = Path(destination).resolve()
        if dest.exists() or dest == self.root or self.root in dest.parents:
            raise JournalError('invalid_restore_destination')
        with self.locked():
            # Checkpoint is outside the snapshot and remains mandatory even when the journal is lost.
            if not self.checkpoint_path.is_file():
                raise JournalError('deletion_frontier_unavailable')
            checkpoint = self.checkpoint()
            spec = json.loads((src / 'snapshot.json').read_text())
            if spec.get('schema') != SCHEMA or spec['corpus_id'] != checkpoint['corpus_id']:
                raise JournalError('snapshot_identity_mismatch')
            if checkpoint['epoch'] < spec.get('deletion_epoch', 0):
                raise JournalError('deletion_frontier_mismatch')
            if 'manifest.json' not in spec.get('files', {}):
                raise JournalError('incomplete_snapshot')
            if any(p.is_symlink() for p in src.rglob('*')):
                raise JournalError('unsafe_snapshot_member')
            if hashlib.sha256((src/'manifest.json').read_bytes()).hexdigest()!=spec['files']['manifest.json']:
                raise JournalError('snapshot_checksum_mismatch')
            original_manifest=json.loads((src/'manifest.json').read_text())
            deliberately_absent=set()
            for key,head in original_manifest.get('heads',{}).items():
                if key in checkpoint['tombstones'] and head.get('blob'):
                    relative='blobs/'+self._blob(head['blob']).name
                    if not (src/relative).exists():deliberately_absent.add(relative)
            for relative, expected in spec['files'].items():
                candidate = src / relative
                if Path(relative).is_absolute() or '..' in Path(relative).parts or candidate.is_symlink() or src not in candidate.resolve().parents:
                    raise JournalError('unsafe_snapshot_member')
                if relative in deliberately_absent:continue
                if not candidate.is_file() or hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
                    raise JournalError('snapshot_checksum_mismatch')
            manifest = json.loads((src / 'manifest.json').read_text())
            if manifest.get('corpus_id') != spec['corpus_id'] or manifest.get('schema') != SCHEMA or manifest.get('min_reader', 999) > READER or manifest.get('generation') != spec.get('generation'):
                raise JournalError('snapshot_identity_mismatch')
            self.checkpoint(manifest)
            for key, head in manifest['heads'].items():
                kind, record_id = key.split(':', 1)
                self.key(kind, record_id)
                if key in checkpoint['tombstones']: continue
                if head['state'] == 'deleted': raise JournalError('incomplete_deletion_frontier')
                relative = 'blobs/' + self._blob(head['blob']).name
                if relative not in spec['files']: raise JournalError('incomplete_snapshot')
                value = json.loads((src / relative).read_text())
                if digest(value) != head['blob'] or value.get('kind') != kind or value.get('id') != record_id or value.get('revision') != head['revision'] or value.get('state') != head['state'] or value.get('owner') != manifest['owner'] or value.get('audience') != [manifest['owner']]:
                    raise JournalError('snapshot_blob_mismatch')
            stage = Path(tempfile.mkdtemp(prefix='.memory-restore-', dir=dest.parent))
            try:
                for relative in spec['files']:
                    if relative in deliberately_absent:continue
                    target = stage / relative;target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(src / relative, target)
                    with target.open('rb') as stream: os.fsync(stream.fileno())
                for relative, expected in spec['files'].items():
                    if relative in deliberately_absent:continue
                    if hashlib.sha256((stage / relative).read_bytes()).hexdigest() != expected:
                        raise JournalError('staged_snapshot_checksum_mismatch')
                manifest = json.loads((stage / 'manifest.json').read_text())
                for key, revision in checkpoint['tombstones'].items():
                    old = manifest['heads'].get(key, {})
                    manifest['heads'][key] = {**old, 'state': 'deleted', 'blob': None, 'revision': max(revision, old.get('revision', 0))}
                for path in (stage / 'blobs').glob('*.json'):
                    value = json.loads(path.read_text())
                    if self.key(value['kind'], value['id']) in checkpoint['tombstones']:
                        path.unlink()
                for path in (stage/'projections').glob('*.json'):
                    value=json.loads(path.read_text())
                    if 'memory:'+str(value.get('id','')) in checkpoint['tombstones']:path.unlink()
                manifest['deletion_epoch'] = checkpoint['epoch']
                self._write(stage / 'manifest.json', manifest)
                for directory in sorted((p for p in stage.rglob('*') if p.is_dir()), key=lambda p:len(p.parts), reverse=True):
                    sync_directory(directory)
                sync_directory(stage)
                os.replace(stage, dest)
                sync_directory(dest.parent)
            finally:
                if stage.exists():shutil.rmtree(stage)
        return dest

    def status(self):
        if not self.available:
            return {'available': False, 'state': 'recovery_required' if self.governed else 'not_initialized', 'protocol': SCHEMA}
        m = self.manifest()
        return {'available': True, 'protocol': SCHEMA, 'owner_only': True, 'generation': m['generation'],
                'policy': m['policy'], 'authority': m['authority_host'] == socket.gethostname(),
                'counts': {kind: sum(k.startswith(kind + ':') and h['state'] != 'deleted' for k,h in m['heads'].items()) for kind in KINDS},
                'deletion_epoch': m['deletion_epoch'], 'adopted': m['adopted']}


def visible_memory(payload, *, review=False):
    """Lower-store compatibility filter. Missing audience stays owner-private."""
    journal = MemoryJournal()
    state = payload.get('state', 'active')
    if state == 'deleted' or (not review and state != 'active'):
        return False
    if journal.governed:
        manifest = journal.manifest()
        key = 'memory:' + str(payload.get('id', ''))
        if key in journal.checkpoint(manifest)['tombstones']:
            return False
        audience = payload.get('audience')
        if audience is not None and manifest['owner'] not in audience:
            return False
        head = manifest['heads'].get(key)
        if head and (head['state'] == 'deleted' or (not review and head['state'] != 'active')):
            return False
        if head:
            current = journal.get('memory', str(payload.get('id', '')), review=review, manifest=manifest)
            if not current: return False
            if payload.get('journal_revision') != current['revision'] or payload.get('journal_blob') != head['blob']:
                return False
            if any(payload.get(k) != v for k,v in current['payload'].items()):
                return False
    elif payload.get('audience') is not None:
        return False
    return True
