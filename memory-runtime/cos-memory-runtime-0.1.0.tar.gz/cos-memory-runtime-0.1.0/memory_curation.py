"""Shadow proposals and independently evaluated, reversible standing-rule versions."""
import hashlib
import json
import os
from pathlib import Path
from memory_journal import MemoryJournal,JournalError,digest,now
from cos_atomic import atomic_write_text

SCRIPTS=Path(__file__).parent
RULES_PATH=Path(os.environ.get('COS_STANDING_RULES_PATH') or SCRIPTS.parent.parent/'.claude/rules/gotchas.md')
EVAL_DIR=Path(os.environ.get('COS_MEMORY_EVAL_DIR') or SCRIPTS/'.memory_evaluations')

def propose(lesson_id,text,*,evidence_refs,trigger='',exclusions=None,journal=None,automatic=False):
    journal=journal or MemoryJournal()
    if not journal.governed:return {'status':'adoption_required','mode':'shadow'}
    if not isinstance(text,str) or not 10<=len(text)<=6000 or not evidence_refs:raise JournalError('invalid_rule_proposal')
    key='rule_'+digest([lesson_id,text,trigger,exclusions or []])
    payload={'lesson_id':lesson_id,'text':text,'evidence_refs':evidence_refs,'trigger':trigger,'exclusions':exclusions or [],
             'mode':'shadow','review':'pending','evaluation':None}
    receipt=journal.mutate('rule',key,payload,expected_revision=0,idempotency_key=key,state='candidate',automatic=automatic)
    return {**receipt,'id':key,'mode':'shadow'}

def review(rule_id,*,expected_revision,idempotency_key,journal=None):
    journal=journal or MemoryJournal()
    request={'action':'review','id':rule_id,'expected_revision':expected_revision}
    with journal.locked():
        manifest=journal.manifest();journal._authority(manifest)
        operation_id=digest({'corpus':manifest['corpus_id'],'key':idempotency_key})
        prior=manifest.get('committed_operations',{}).get(operation_id)
        if prior:
            original=json.loads(journal._blob(prior['blob']).read_text())
            if prior['record_key']!='rule:'+rule_id or original['payload'].get('mutation_request')!=request:
                raise JournalError('idempotency_conflict')
            return prior
        value=journal.get('rule',rule_id,review=True)
        if not value:raise JournalError('rule_not_found')
        if value['state']!='candidate':raise JournalError('rule_not_candidate')
        return journal._mutate_locked('rule',rule_id,{**value['payload'],'review':'approved_by_owner','mutation_request':request},state='candidate',
                              expected_revision=expected_revision,idempotency_key=idempotency_key)

def candidate_hash(payload):
    return digest({k:payload.get(k) for k in ('lesson_id','text','evidence_refs','trigger','exclusions')})

def evaluation(rule_id,evaluation_id,journal=None,*,inspect=False):
    journal=journal or MemoryJournal();value=journal.get('rule',rule_id,review=True)
    if not value:raise JournalError('rule_not_found')
    import re
    if not isinstance(evaluation_id,str) or not re.fullmatch('[A-Za-z0-9_-]{1,160}',evaluation_id):raise JournalError('invalid_evaluation_id')
    try:data=json.loads((EVAL_DIR/(evaluation_id+'.json')).read_text())
    except FileNotFoundError as exc:raise JournalError('evaluation_not_found') from exc
    except (OSError,ValueError) as exc:raise JournalError('evaluation_unreadable') from exc
    raw={k:v for k,v in data.items() if k!='checksum'}
    from memory_evaluation_receipts import verify
    verify('rule_evaluation',{k:v for k,v in raw.items() if k!='evaluator_receipt'},data.get('evaluator_receipt'),journal)
    if inspect and value['state'] in {'active','superseded'}:
        bound=value['payload'].get('evaluation') or {}
        if bound.get('id')!=evaluation_id or bound.get('checksum')!=data.get('checksum') or data.get('checksum')!=digest(raw) or data.get('candidate_hash')!=candidate_hash(value['payload']):
            raise JournalError('evaluation_mismatch')
        return {**data,'inspection':'historical_activation_evidence','current_rule_revision':value['revision']}
    if data.get('checksum')!=digest(raw) or data.get('candidate_hash')!=candidate_hash(value['payload']) or data.get('candidate_revision')!=value['revision'] or data.get('policy_revision')!=journal.policy()['revision']:raise JournalError('evaluation_mismatch')
    cases=data.get('cases',[])
    if not cases or any(c.get('result')!='passed' for c in cases) or not {'trigger','counterexample','exclusion','regression'}<=set(c.get('category') for c in cases):
        raise JournalError('evaluation_gate_failed')
    if data.get('evaluator') not in {'deterministic_runner','human_review'}:raise JournalError('independent_evaluation_required')
    return data

def _prior(journal,rule_id,key,request):
    manifest=journal.manifest();operation_id=digest({'corpus':manifest['corpus_id'],'key':key})
    receipt=manifest.get('committed_operations',{}).get(operation_id)
    if not receipt:return None
    if receipt['record_key']!='rule:'+rule_id:raise JournalError('idempotency_conflict')
    original=json.loads(journal._blob(receipt['blob']).read_text())
    if original['payload'].get('mutation_request')!=request:raise JournalError('idempotency_conflict')
    head=manifest['heads']['rule:'+rule_id]
    if head['operation_id']!=operation_id:return {**receipt,'status':'superseded','projection':'historical_receipt'}
    try:projection=project(rule_id,journal,_lock_held=True)
    except (OSError,JournalError) as exc:return {**receipt,'status':'pending_projection','error':str(exc)}
    return {**receipt,'status':'activated' if original['state']=='active' else 'reverted','projection':projection}

def _intent(journal,rule_id,key):
    op=digest({'corpus':journal.manifest()['corpus_id'],'key':key})
    journal._write(journal.root/'rule_projections'/(op+'.json'),{'rule_id':rule_id,'operation_id':op})

def activate(rule_id,*,expected_revision,idempotency_key,evaluation_id,journal=None):
    journal=journal or MemoryJournal()
    with journal.locked():
        manifest=journal.manifest();journal._authority(manifest)
        request={'action':'activate','id':rule_id,'expected_revision':expected_revision,'evaluation_id':evaluation_id}
        prior=_prior(journal,rule_id,idempotency_key,request)
        if prior:return prior
        value=journal.get('rule',rule_id,review=True)
        if not value:raise JournalError('rule_not_found')
        if value['revision']!=expected_revision:raise JournalError('revision_conflict')
        if value['state']!='candidate':raise JournalError('rule_not_candidate')
        if value['payload'].get('review')!='approved_by_owner':raise JournalError('owner_review_required')
        evidence=evaluation(rule_id,evaluation_id,journal)
        before=RULES_PATH.read_text() if RULES_PATH.is_file() else ''
        payload={**value['payload'],'mode':'active','evaluation':{'id':evaluation_id,'checksum':evidence['checksum']},
                 'base_hash':hashlib.sha256(before.encode()).hexdigest(),'mutation_request':request}
        _intent(journal,rule_id,idempotency_key)
        receipt=journal._mutate_locked('rule',rule_id,payload,state='active',expected_revision=expected_revision,idempotency_key=idempotency_key)
        try:projection=project(rule_id,journal,_lock_held=True)
        except (OSError,JournalError) as exc:return {**receipt,'status':'activation_pending_projection','error':str(exc)}
        return {**receipt,'projection':projection,'status':'activated'}

def _block(rule_id,payload):
    applicability='Applies when: '+(payload.get('trigger') or 'No trigger specified; revalidate before use.')
    exclusions='Excludes: '+('; '.join(payload.get('exclusions') or []) or 'No explicit exclusions recorded.')
    return '\n<!-- cos-rule:'+rule_id+' -->\n'+applicability+'\n'+exclusions+'\n'+payload['text'].strip()+'\n<!-- /cos-rule:'+rule_id+' -->\n'

def project(rule_id,journal=None,*,_lock_held=False):
    journal=journal or MemoryJournal()
    if not _lock_held:
        with journal.locked():return project(rule_id,journal,_lock_held=True)
    value=journal.get('rule',rule_id,review=True);journal._authority(journal.manifest())
    if not value or value['state'] not in {'active','superseded'}:raise JournalError('rule_not_projectable')
    payload=value['payload'];text=RULES_PATH.read_text() if RULES_PATH.is_file() else '';block=_block(rule_id,payload)
    if value['state']=='active':
        if block not in text:
            if hashlib.sha256(text.encode()).hexdigest()!=payload['base_hash']:raise JournalError('rule_target_changed')
            atomic_write_text(RULES_PATH,text+block,durable=True)
    else:
        if '<!-- cos-rule:'+rule_id+' -->' in text and block not in text:raise JournalError('rule_target_changed')
        if block in text:atomic_write_text(RULES_PATH,text.replace(block,'',1),durable=True)
    receipt={'status':'applied','rule_id':rule_id,'revision':value['revision'],'operation_id':value['operation_id']}
    journal._write(journal.root/'rule_projection_receipts'/(value['operation_id']+'.json'),receipt)
    return receipt

def rollback(rule_id,*,expected_revision,idempotency_key,journal=None):
    journal=journal or MemoryJournal()
    with journal.locked():
        journal._authority(journal.manifest())
        request={'action':'rollback','id':rule_id,'expected_revision':expected_revision}
        prior=_prior(journal,rule_id,idempotency_key,request)
        if prior:return prior
        value=journal.get('rule',rule_id,review=True)
        if not value:raise JournalError('rule_not_found')
        if value['revision']!=expected_revision:raise JournalError('revision_conflict')
        if value['state']!='active':raise JournalError('rule_not_active')
        block=_block(rule_id,value['payload']);text=RULES_PATH.read_text() if RULES_PATH.is_file() else ''
        if '<!-- cos-rule:'+rule_id+' -->' in text and block not in text:raise JournalError('rule_target_changed')
        _intent(journal,rule_id,idempotency_key)
        receipt=journal._mutate_locked('rule',rule_id,{**value['payload'],'mutation_request':request},state='superseded',expected_revision=expected_revision,idempotency_key=idempotency_key)
        try:projection=project(rule_id,journal,_lock_held=True)
        except (OSError,JournalError) as exc:return {**receipt,'status':'rollback_pending_projection','error':str(exc)}
        return {**receipt,'status':'reverted','projection':projection}

def reconcile(journal=None):
    journal=journal or MemoryJournal();results=[]
    with journal.locked():
        manifest=journal.manifest();journal._authority(manifest)
        for path in sorted((journal.root/'rule_projections').glob('*.json')):
            if (journal.root/'rule_projection_receipts'/path.name).is_file():continue
            task=json.loads(path.read_text());head=manifest['heads'].get('rule:'+task['rule_id'])
            if not head or head['operation_id']!=task['operation_id']:
                results.append({'operation_id':task['operation_id'],'status':'not_current_committed_projection'});continue
            try:results.append(project(task['rule_id'],journal,_lock_held=True))
            except (OSError,JournalError) as exc:results.append({'operation_id':task['operation_id'],'status':'pending_projection','error':str(exc)})
    return results
