#!/usr/bin/env python3
"""Local setup tools; RPC users cannot supply arbitrary source paths."""
import argparse
import json
import os
from pathlib import Path
from runtime_config import configure
configure()
from memory_journal import MemoryJournal,digest
from memory_sources import REGISTRY,registry,refresh_document
from cos_atomic import atomic_write_json

def grant(path,title):
    source=path.expanduser().resolve(strict=True)
    if not source.is_file() or source.suffix.lower() not in {'.md','.txt'}:raise ValueError('only_markdown_and_text_sources')
    source_id='source_'+digest(str(source));data=registry()
    data['sources'][source_id]={'path':str(source),'resolved_path':str(source),'grant_root':str(source.parent),'title':title or source.stem,'kind':'document'}
    atomic_write_json(REGISTRY,data,durable=True);REGISTRY.chmod(0o600)
    journal=MemoryJournal();previous=journal.get('source',source_id)
    result=refresh_document(source_id,expected_revision=previous['revision'] if previous else 0,idempotency_key='refresh_'+digest([source_id,source.read_text()]),journal=journal)
    from source_index import build
    return {'source':result,'index':build(journal)}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['grant','index','backup','restore','activate']);p.add_argument('path',nargs='?',type=Path);p.add_argument('--title');p.add_argument('--destination',type=Path);a=p.parse_args();j=MemoryJournal()
    if a.action=='grant':result=grant(a.path,a.title)
    elif a.action=='index':
        from source_index import build
        result=build(j)
    elif a.action=='backup':result={'snapshot':str(j.snapshot(a.path)),'independent_deletion_frontier':str(j.checkpoint_path)}
    elif a.action=='restore':
        from memory_generations import prepare
        result=prepare(a.path,a.destination,journal=j,graph_index=os.environ['COS_GRAPH_INDEX_PATH'] if Path(os.environ['COS_GRAPH_INDEX_PATH']).is_file() else None)
    else:
        from memory_generations import activate
        result=activate(a.path,journal=j)
    print(json.dumps(result))
