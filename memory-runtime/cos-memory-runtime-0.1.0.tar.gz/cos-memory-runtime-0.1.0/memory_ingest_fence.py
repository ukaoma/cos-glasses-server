"""Process-local witness for an actual SDK flock; contains no private paths.

Only the lock owner registers its held object. A closed object or inherited
state in a fork cannot authorize a generation switch.
"""
import contextvars
import os

held = contextvars.ContextVar('cos_ingest_lock_mode', default=None)


def local_ingest_mode():
    value=held.get()
    return value[1].mode if value and value[0]==os.getpid() and not value[1].closed else None
