"""Journal is the public file runtime's searchable store; no vector projection exists."""
import json
from memory_journal import MemoryJournal,JournalError,digest

def revise(record_id,changes,*,expected_revision,idempotency_key,state=None,journal=None,**kwargs):
    journal=journal or MemoryJournal();manifest=journal.manifest()
    request_hash=digest({'changes':changes,'state':state,'expected_revision':expected_revision})
    op=digest({'corpus':manifest['corpus_id'],'key':idempotency_key})
    prior=manifest.get('committed_operations',{}).get(op)
    if prior:
        if prior.get('record_key')!='memory:'+record_id or prior.get('caller_request_hash')!=request_hash:raise JournalError('idempotency_conflict')
        return prior
    value=journal.get('memory',record_id,review=True)
    if not value:raise JournalError('memory_not_found')
    return journal.mutate('memory',record_id,{**value['payload'],**changes},state=state or value['state'],expected_revision=expected_revision,idempotency_key=idempotency_key,caller_request_hash=request_hash)

def forget(record_id,*,expected_revision,idempotency_key,journal=None,**kwargs):
    journal=journal or MemoryJournal()
    receipt=journal.mutate('memory',record_id,{},state='deleted',expected_revision=expected_revision,idempotency_key=idempotency_key)
    return {**receipt,'status':'deleted','managed_searchable_content':'removed','external_sources':'not_deleted','backups':'retain_content_until_selective_purge'}
