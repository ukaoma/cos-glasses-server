"""Shared current-source boundary for graph, vector and derived-memory readers."""
import json
from pathlib import Path
from memory_journal import MemoryJournal


def lineage(journal=None,*,manifest=None):
    journal=journal or MemoryJournal()
    if journal.governed:manifest=manifest or journal.manifest()
    fingerprint=grant_fingerprint()
    cache_key=((manifest or {}).get('generation'),fingerprint)
    cached=getattr(journal,'_source_lineage_cache',None)
    if cached and cached[0]==cache_key:return cached[1]
    if not journal.available:return {'chunks':set(),'docs':set(),'paths':set(),'sources':{}}
    from memory_sources import excluded_chunks
    chunks,docs=excluded_chunks(journal);paths=set();sources={}
    from memory_sources import current_sources
    visible={row['id'] for row in current_sources(journal)}
    for row in journal.list('source'):
        payload=row['payload']
        sources[row['id']]={'revision':row['revision'],'hash':payload.get('content_hash'),'visible':row['id'] in visible,'path':payload.get('resolved_path'),'paths':payload.get('legacy_paths',[])+[payload.get('resolved_path')]}
        paths.update(str(value) for value in payload.get('legacy_paths',[]) if value)
        if payload.get('resolved_path'):paths.add(payload['resolved_path'])
    result={'chunks':chunks,'docs':docs,'paths':paths,'sources':sources}
    journal._source_lineage_cache=(cache_key,result)
    return result


def payload_allowed(payload,journal=None,*,policy=None):
    policy=policy if policy is not None else lineage(journal)
    if not any(policy.values()):return True
    values=[]
    def collect(value):
        if isinstance(value,dict):
            for key,item in value.items():
                if key in {'content','summary','text','excerpt'}:continue
                collect(item)
        elif isinstance(value,list):
            for item in value:collect(item)
        elif isinstance(value,str):
            if value.startswith(('{','[')):
                try:collect(json.loads(value));return
                except ValueError:pass
            values.append(value)
    for key in ('refs','source_refs','file_path','canonical_file_path','meeting_id','doc_id','chunk_id','source_id','evidence_refs'):
        collect(payload.get(key))
    implicated=set()
    for value in values:
        if value in policy['chunks'] or value in policy['docs']:return False
        for source_id,source in policy.get('sources',{}).items():
            path=source.get('path')
            if value==source_id or any(path_matches(value,p) for p in source.get('paths',[]) if p):implicated.add(source_id)
    versions=payload.get('source_versions',[])
    if not isinstance(versions,list):return False
    for version in versions:
        if not isinstance(version,dict) or version.get('source_id') not in policy.get('sources',{}):return False
        implicated.add(version['source_id'])
    for source_id in implicated:
        current=policy['sources'][source_id]
        if not current['visible'] or not any(isinstance(v,dict) and v.get('source_id')==source_id and v.get('revision')==current['revision'] and v.get('content_hash')==current['hash'] for v in versions):return False
    return True


def path_matches(value,path):
    if not isinstance(value,str) or not value:return False
    import os
    normalized=os.path.normpath(value);target=os.path.normpath(path)
    if os.path.isabs(normalized):
        try:normalized=str(Path(normalized).resolve(strict=False))
        except OSError:pass
    return normalized==target or target.endswith('/'+normalized.lstrip('./'))



def apply_graph_views(conn,journal=None):
    """Filter before ranking/counts; never disclose a blended aggregate with excluded inputs."""
    policy=lineage(journal)
    if not policy['chunks'] and not policy['docs'] and not policy['paths']:return False
    columns={r[0] for r in conn.execute("SELECT name FROM main.sqlite_master WHERE type='table'")}
    if 'docs' in columns and policy['paths']:
        for row in conn.execute('SELECT doc_id,source_key FROM main.docs'):
            if any(path_matches(row[1],path) for path in policy['paths']):policy['docs'].add(row[0])
    mapping={r[0]:r[1] for r in conn.execute('SELECT chunk_id,doc_id FROM main.chunks')} if 'chunks' in columns else {}
    def allowed_one(chunk):
        return bool(chunk) and chunk not in policy['chunks'] and (not policy['docs'] or chunk in mapping and mapping[chunk] is not None and mapping[chunk] not in policy['docs'])
    def aggregate(raw):
        ids=[x for x in str(raw or '').split('<SEP>') if x]
        return bool(ids) and all(allowed_one(x) for x in ids)
    conn.create_function('cos_allowed_chunk',1,allowed_one,deterministic=True)
    conn.create_function('cos_allowed_aggregate',1,aggregate,deterministic=True)
    if 'edges' in columns:
        conn.execute("CREATE TEMP VIEW edges AS SELECT rowid AS rowid,* FROM main.edges e WHERE cos_allowed_aggregate(e.source_ids) AND EXISTS(SELECT 1 FROM main.entities n WHERE n.id=e.src AND cos_allowed_aggregate(n.source_ids)) AND EXISTS(SELECT 1 FROM main.entities n WHERE n.id=e.tgt AND cos_allowed_aggregate(n.source_ids))")
    if 'entities' in columns:
        fields=[r[1] for r in conn.execute('PRAGMA main.table_info(entities)')]
        select=','.join('(SELECT COUNT(*) FROM temp.edges WHERE src=e.id OR tgt=e.id) AS degree' if field=='degree' else 'e."'+field+'"' for field in fields)
        conn.execute('CREATE TEMP VIEW entities AS SELECT e.rowid AS rowid,'+select+' FROM main.entities e WHERE cos_allowed_aggregate(e.source_ids)')
    for table in ('chunks','entity_chunks','relation_chunks'):
        if table in columns:conn.execute(f'CREATE TEMP VIEW {table} AS SELECT * FROM main.{table} WHERE cos_allowed_chunk(chunk_id)')
    if 'docs' in columns:
        fields=[r[1] for r in conn.execute('PRAGMA main.table_info(docs)')]
        select=','.join('NULL AS summary' if field=='summary' else '"'+field+'"' for field in fields)
        conn.execute('CREATE TEMP VIEW docs AS SELECT '+select+' FROM main.docs')
    return True

def grant_fingerprint():
    """Resolved grant identity participates in every cached/current graph generation."""
    import hashlib
    from memory_sources import REGISTRY,registry
    data=registry();items=[]
    proof_path=MemoryJournal().state_root/'replica-authority.json'
    if proof_path.is_file():
        proof=json.loads(proof_path.read_text())
        items.append(['replica_authority_grants',proof.get('corpus_id'),proof.get('authority_epoch'),sorted(proof.get('source_ids',[]))])
    for key,entry in sorted(data['sources'].items()):
        try:
            path=Path(entry['path']).expanduser().resolve(strict=True)
            grant=Path(entry.get('grant_root') or path.parent).expanduser().resolve(strict=True)
            resolved=[str(path),str(grant),path.is_file()]
        except (OSError,KeyError,ValueError):resolved=['unavailable']
        items.append([key,entry,resolved])
    return hashlib.sha256(json.dumps(items,sort_keys=True).encode()).hexdigest()[:20]
